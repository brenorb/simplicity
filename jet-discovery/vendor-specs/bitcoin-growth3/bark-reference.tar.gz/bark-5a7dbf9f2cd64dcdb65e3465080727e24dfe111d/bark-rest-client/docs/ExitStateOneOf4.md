# ExitStateOneOf4

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**claim_txid** | **String** |  | 
**claimable_since** | [**models::BlockRef**](BlockRef.md) |  | 
**tip_height** | **i32** |  | 
**r#type** | **Type** |  (enum: claim-in-progress) | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


