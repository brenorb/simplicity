# ChainSourceConfigOneOf1

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**esplora** | [**models::ChainSourceConfigOneOf1Esplora**](ChainSourceConfigOneOf1Esplora.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


