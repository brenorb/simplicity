# ExitErrorOneOf15

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**txid** | **String** |  | 
**r#type** | **Type** |  (enum: exit-tx-already-broadcast) | 
**vtxo** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


