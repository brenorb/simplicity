# RoundStatusOneOf4

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** |  | 
**status** | **Status** |  (enum: failed) | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


