# ExitTxStatusOneOf3

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**child_txid** | **String** |  | 
**origin** | [**models::ExitTxOrigin**](ExitTxOrigin.md) |  | 
**r#type** | **Type** |  (enum: awaiting-confirmation) | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


