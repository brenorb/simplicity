# ExitErrorOneOf18

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** |  | 
**status** | [**models::ExitTxStatus**](ExitTxStatus.md) |  | 
**txid** | **String** |  | 
**r#type** | **Type** |  (enum: invalid-exit-transaction-status) | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


