# ExitErrorOneOf14

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** |  | 
**txid** | **String** |  | 
**r#type** | **Type** |  (enum: exit-package-store-failure) | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


