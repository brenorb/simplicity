# ExitStartState

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tip_height** | **i32** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


