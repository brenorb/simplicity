# ExitClaimedState

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**block** | [**models::BlockRef**](BlockRef.md) |  | 
**tip_height** | **i32** |  | 
**txid** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


