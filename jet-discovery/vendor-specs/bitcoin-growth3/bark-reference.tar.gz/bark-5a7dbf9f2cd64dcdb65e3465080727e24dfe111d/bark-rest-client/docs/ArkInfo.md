# ArkInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fees** | [**models::FeeSchedule**](FeeSchedule.md) | The fee schedule outlining any fees that must be paid to interact with the Ark server. | 
**htlc_expiry_delta** | **i32** | The number of blocks to keep between Lightning and Ark HTLCs expiries | 
**htlc_send_expiry_delta** | **i32** | The number of blocks after which an HTLC-send VTXO expires once granted. | 
**ln_receive_anti_dos_required** | **bool** | Indicates whether the Ark server requires clients to either provide a VTXO ownership proof, or a lightning receive token when preparing a lightning claim. | 
**mailbox_pubkey** | **String** | The pubkey used for blinding unified mailbox IDs | 
**max_offboard_inputs** | **i32** | The maximum number of inputs for an offboard | 
**max_user_invoice_cltv_delta** | **i32** | Maximum CLTV delta server will allow clients to request an invoice generation with. | 
**max_vtxo_amount** | **i64** | Maximum amount of a VTXO | 
**max_vtxo_exit_depth** | **i32** | Maximum exit depth (genesis chain length) allowed for a VTXO. Once a VTXO's exit depth reaches this value the server will refuse to cosign further OOR transactions spending it. Clients should refresh their VTXOs into a round before this limit is reached. | 
**min_board_amount_sat** | **i64** | Minimum amount for a board the server will cosign | 
**nb_round_nonces** | **i32** | Number of nonces per round | 
**network** | **String** | The bitcoin network the server operates on | 
**offboard_feerate_sat_per_kvb** | **i64** | offboard feerate in sat per kvb | 
**required_board_confirmations** | **i32** | The number of confirmations required to register a board vtxo | 
**round_interval** | **String** | The interval between each round | 
**server_pubkey** | **String** | The Ark server pubkey | 
**tos_link** | Option<**String**> | Link to the server's terms of service, if any. | [optional]
**vtxo_exit_delta** | **i32** | Delta between exit confirmation and coins becoming spendable | 
**vtxo_expiry_delta** | **i32** | The number of blocks a VTXO lives before it expires.  **Deprecated**: renamed to `vtxo_lifetime`. This field is still populated with the same value for backwards compatibility and will be removed in a future release. | 
**vtxo_lifetime** | Option<**i32**> | The number of blocks a VTXO lives before it expires | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


