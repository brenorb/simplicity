
use std::borrow::BorrowMut;
use std::collections::{HashMap, HashSet};
use std::sync::Arc;

use bdk_wallet::{AddressInfo, TxBuilder, Utxo, Wallet, WeightedUtxo};
use bdk_wallet::chain::{BlockId, CanonicalizationParams, ChainPosition, ConfirmationBlockTime};
use bdk_wallet::coin_selection::{
	decide_change, CoinSelectionAlgorithm, CoinSelectionResult, DefaultCoinSelectionAlgorithm,
	Excess, InsufficientFunds,
};
use bdk_wallet::descriptor::{DescriptorError, IntoWalletDescriptor};
use bdk_wallet::error::CreateTxError;
use bdk_wallet::miniscript::ForEachKey;
use bdk_wallet::signer::SignersContainer;
use bitcoin::consensus::encode::{serialize, serialize_hex};
use bitcoin::{
	Amount, BlockHash, FeeRate, OutPoint, Script, Transaction, TxOut, Txid, Weight, Witness,
};
use bitcoin::psbt::{ExtractTxError, Input};
use log::debug;
use rand_core::RngCore;

use crate::TransactionExt;
use crate::cpfp::MakeCpfpFees;
use crate::fee::FEE_ANCHOR_SPEND_WEIGHT;

/// One canonical wallet tx, with its trust verdict already decided.
#[derive(Debug, Clone)]
pub struct LocalTransaction {
	/// Refcounted handle into BDK's in-memory tx graph; cloning is cheap.
	pub tx: Arc<Transaction>,
	pub chain_position: ChainPosition<ConfirmationBlockTime>,
	pub is_trusted: bool,
}

/// Borrowed view of one of our unspent outputs, returned by
/// [`TrustedCanonicalization::list_unspent`]. Carries the trust verdict
/// already decided for the creating tx so callers don't re-look-it-up.
pub struct TrustedUtxo<'a> {
	pub outpoint: OutPoint,
	pub txout: &'a TxOut,
	pub chain_position: &'a ChainPosition<ConfirmationBlockTime>,
	pub is_trusted: bool,
}

/// Single-pass canonical view of the wallet's tx graph with trust
/// verdicts pre-computed.
///
/// Built via one [`TxGraph::list_ordered_canonical_txs`] call which
/// yields txs in topological (parents-before-children) order. We mark
/// each tx trusted/untrusted in that order, so by the time we look at a
/// tx every ancestor is already decided — no recursion, no per-tx
/// `Wallet::get_tx`, no ancestor-walk budget heuristic.
///
/// In the same pass we also collect this wallet's UTXOs (ours-outpoints
/// from the keychain index, minus anything consumed by another canonical
/// tx). [`TrustedCanonicalization::list_unspent`] returns them without
/// triggering a second canonicalization the way [`Wallet::list_unspent`]
/// would.
///
/// [`TxGraph::list_ordered_canonical_txs`]: bdk_wallet::chain::TxGraph::list_ordered_canonical_txs
pub struct TrustedCanonicalization {
	txs: HashMap<Txid, LocalTransaction>,
	unspent: Vec<OutPoint>,
}

impl TrustedCanonicalization {
	/// Take one canonicalization snapshot of `w` and decide trust for
	/// every canonical tx using `min_confs` as the confirmation
	/// threshold.
	pub fn from_wallet(w: &Wallet, min_confs: u32) -> Self {
		let tip = w.latest_checkpoint().height();
		let chain = w.local_chain();
		let chain_tip = w.latest_checkpoint().block_id();

		let mut txs: HashMap<Txid, LocalTransaction> = HashMap::new();
		let mut spent: HashSet<OutPoint> = HashSet::new();

		for ctx in w.tx_graph().list_ordered_canonical_txs(
			chain, chain_tip, CanonicalizationParams::default(),
		) {
			let txid = ctx.tx_node.txid;
			let tx = ctx.tx_node.tx.clone();
			let chain_position = ctx.chain_position.clone();

			for input in tx.input.iter() {
				spent.insert(input.previous_output);
			}

			let nb_confs = match chain_position.confirmation_height_upper_bound() {
				Some(h) => tip.saturating_sub(h) + 1,
				None => 0,
			};
			let is_trusted = nb_confs >= min_confs || tx.input.iter().all(|input| {
				let prev = input.previous_output;
				let Some(prev_entry) = txs.get(&prev.txid) else { return false };
				let Some(prev_out) = prev_entry.tx.output.get(prev.vout as usize) else { return false };
				// Trust rule: this input must spend an output of ours,
				// AND the prev tx itself must already be trusted.
				// Topological order guarantees the prev entry is
				// fully decided.
				w.is_mine(prev_out.script_pubkey.clone()) && prev_entry.is_trusted
			});

			txs.insert(txid, LocalTransaction { tx, chain_position, is_trusted });
		}

		// Unspent = ours-outpoints (from the keychain index) ∩ canonical
		// txs ∖ spent. Mirrors `Wallet::list_unspent`'s use of
		// `spk_index().outpoints()` but reuses the canonical view we
		// just built instead of running a second canonicalization.
		let unspent = w.spk_index().outpoints().iter()
			.map(|(_, op)| *op)
			.filter(|op| !spent.contains(op))
			.filter(|op| txs.contains_key(&op.txid))
			.collect();

		Self { txs, unspent }
	}

	/// The canonical tx for `txid`, or `None` when this view does not
	/// hold it.
	pub fn get(&self, txid: Txid) -> Option<&LocalTransaction> {
		self.txs.get(&txid)
	}

	/// Trust verdict for `txid`. Unknown txids (not in the wallet's
	/// canonical view) are treated as untrusted.
	pub fn is_trusted(&self, txid: Txid) -> bool {
		self.get(txid).map(|e| e.is_trusted).unwrap_or(false)
	}

	/// Iterate this wallet's unspent outputs in canonical view, each
	/// carrying its trust verdict.
	pub fn list_unspent(&self) -> impl Iterator<Item = TrustedUtxo<'_>> + '_ {
		self.unspent.iter().map(move |op| {
			let lt = &self.txs[&op.txid];
			TrustedUtxo {
				outpoint: *op,
				txout: &lt.tx.output[op.vout as usize],
				chain_position: &lt.chain_position,
				is_trusted: lt.is_trusted,
			}
		})
	}
}

/// Balance categorized by our recursive trust model.
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct TrustedBalance {
	/// Funds in UTXOs we trust (confirmed or all-ours unconfirmed chains).
	pub trusted: Amount,
	/// Funds in UTXOs we don't trust.
	pub untrusted: Amount,
}

impl TrustedBalance {
	pub fn total(&self) -> Amount {
		self.trusted + self.untrusted
	}
}

/// The [bdk_wallet::KeychainKind] that is always used, because we only use a single keychain.
pub const KEYCHAIN: bdk_wallet::KeychainKind = bdk_wallet::KeychainKind::External;


/// Coin selection wrapper that guarantees the transaction keeps a change (drain) output, so
/// there is always a wallet-owned output left to CPFP. The selection is made to cover a non-dust
/// change value plus the fee that the extra output adds.
///
/// BDK's algorithms stop selecting coins as soon as the target amount is covered. If the
/// selected coins overshoot the target by less than the dust limit, the leftover is too small to
/// be a valid output. Normally BDK would drop it and let it go to fees, but when the drain is the
/// transaction's only output, dropping it leaves no outputs at all, so `TxBuilder::finish` fails
/// with [InsufficientFunds] — even if the wallet has plenty of other coins available.
///
/// This wrapper asks the inner algorithm for slightly more: the dust limit, plus the fee the
/// drain output itself adds. That makes it keep pulling in coins until the leftover is a valid
/// output. The result is then adjusted so that the extra ends up in the drain output rather than
/// being burned as fee.
#[derive(Debug, Clone, Copy, Default)]
pub struct WithGuaranteedChange<A>(pub A);

impl<A: CoinSelectionAlgorithm> CoinSelectionAlgorithm for WithGuaranteedChange<A> {
	fn coin_select<R: RngCore>(
		&self,
		required_utxos: Vec<WeightedUtxo>,
		optional_utxos: Vec<WeightedUtxo>,
		fee_rate: FeeRate,
		target_amount: Amount,
		drain_script: &Script,
		rand: &mut R,
	) -> Result<CoinSelectionResult, InsufficientFunds> {
		// Fee cost of the drain output itself, computed exactly like bdk_wallet's `decide_change`
		// does: the leftover only becomes change after paying for the extra output, so selection
		// must cover that fee too. Zero when the caller uses an absolute fee, since BDK then
		// passes FeeRate::ZERO here.
		let drain_output_len = serialize(drain_script).len() + 8;
		let drain_output_fee = fee_rate
			* Weight::from_vb(drain_output_len as u64).expect("script length fits in Weight");
		let raise = drain_script.minimal_non_dust() + drain_output_fee;

		let mut result = self.0.coin_select(
			required_utxos, optional_utxos, fee_rate, target_amount + raise, drain_script, rand,
		)?;

		// The inner algorithm measured its leftover against the raised target, so the raise is
		// missing from its excess. Add it back and decide the change against the real target:
		// the leftover is then at least `raise`, so this always yields a non-dust
		// `Excess::Change`.
		let leftover = match result.excess {
			Excess::Change { amount, fee } => amount + fee,
			Excess::NoChange { remaining_amount, .. } => remaining_amount,
		};
		result.excess = decide_change(leftover + raise, fee_rate, drain_script);
		Ok(result)
	}
}

/// Coin selection wrapper that favours confirmed inputs: the inner algorithm first runs over the
/// confirmed candidates only. When confirmed funds don't suffice, all of them become required
/// inputs and the unconfirmed ones (foreign utxos included) are offered to top up the difference.
///
/// A tx spending only confirmed inputs relays at exactly the feerate it pays and can't be
/// dragged down by a low-fee parent. When unconfirmed inputs can't be avoided, spending every
/// confirmed coin first keeps the unconfirmed share as small as possible.
#[derive(Debug, Clone, Copy, Default)]
pub struct PreferConfirmedCoinSelection<A>(pub A);

impl<A: CoinSelectionAlgorithm> CoinSelectionAlgorithm for PreferConfirmedCoinSelection<A> {
	fn coin_select<R: RngCore>(
		&self,
		required_utxos: Vec<WeightedUtxo>,
		optional_utxos: Vec<WeightedUtxo>,
		fee_rate: FeeRate,
		target_amount: Amount,
		drain_script: &Script,
		rand: &mut R,
	) -> Result<CoinSelectionResult, InsufficientFunds> {
		let (confirmed, unconfirmed) = optional_utxos.into_iter()
			.partition::<Vec<_>, _>(|wu| match wu.utxo {
				Utxo::Local(ref o) => o.chain_position.is_confirmed(),
				Utxo::Foreign { .. } => false,
			});

		let attempt = self.0.coin_select(
			required_utxos.clone(), confirmed.clone(), fee_rate, target_amount,
			drain_script, rand,
		);
		match attempt {
			Ok(result) => Ok(result),
			Err(InsufficientFunds { .. }) => {
				let required = required_utxos.into_iter().chain(confirmed).collect();
				self.0.coin_select(
					required, unconfirmed, fee_rate, target_amount, drain_script, rand,
				)
			},
		}
	}
}

/// An extension trait for [TxBuilder].
pub trait TxBuilderExt<'a, A>: BorrowMut<TxBuilder<'a, A>> {
	/// Add an input to the tx that spends a fee anchor.
	fn add_fee_anchor_spend(&mut self, anchor: OutPoint, output: &TxOut)
	where
		A: bdk_wallet::coin_selection::CoinSelectionAlgorithm,
	{
		let psbt_in = Input {
			witness_utxo: Some(output.clone()),
			final_script_witness: Some(Witness::new()),
			..Default::default()
		};
		self.borrow_mut().add_foreign_utxo(anchor, psbt_in, FEE_ANCHOR_SPEND_WEIGHT)
			.expect("adding foreign utxo");
	}
}
impl<'a, A> TxBuilderExt<'a, A> for TxBuilder<'a, A> {}

#[derive(Debug, thiserror::Error)]
pub enum CpfpInternalError {
	#[error("{0}")]
	General(String),
	#[error("Unable to construct transaction: {0}")]
	Create(CreateTxError),
	#[error("Unable to extract the final transaction after signing the PSBT: {0}")]
	Extract(ExtractTxError),
	#[error("Failed to determine the weight/fee when creating a P2A CPFP")]
	Fee(),
	#[error("Unable to finalize CPFP transaction: {0}")]
	FinalizeError(String),
	#[error("You need more confirmations on your on-chain funds: {0}")]
	InsufficientConfirmedFunds(InsufficientFunds),
	#[error("Transaction has no fee anchor: {0}")]
	NoFeeAnchor(Txid),
	#[allow(deprecated)]
	#[error("Unable to sign transaction: {0}")]
	Signer(bdk_wallet::signer::SignerError),
}

#[derive(Debug, thiserror::Error)]
pub enum BuildSignersError {
	#[error("Invalid descriptor: {0}")]
	Descriptor(DescriptorError),
	#[error("Descriptor does not match the wallet descriptor")]
	DescriptorMismatch,
	#[error("Descriptor does not hold all private keys")]
	MissingPrivateKeys,
}

/// An extension trait for [Wallet].
pub trait WalletExt: BorrowMut<Wallet> {
	/// Peek into the next address.
	fn peek_next_address(&self) -> AddressInfo {
		self.borrow().peek_address(KEYCHAIN, self.borrow().next_derivation_index(KEYCHAIN))
	}

	/// Build the software signers for this wallet from a descriptor that
	/// holds the private keys.
	///
	/// Fails if the descriptor is not the wallet descriptor, or if a key in
	/// the descriptor has no private key.
	fn build_signers(
		&self,
		desc: impl IntoWalletDescriptor,
	) -> Result<SignersContainer, BuildSignersError> {
		let wallet = self.borrow();
		let (public_desc, keymap) = desc
			.into_wallet_descriptor(wallet.secp_ctx(), wallet.network().into())
			.map_err(BuildSignersError::Descriptor)?;
		if public_desc != *wallet.public_descriptor(KEYCHAIN) {
			return Err(BuildSignersError::DescriptorMismatch);
		}
		if !public_desc.for_each_key(|pk| keymap.contains_key(pk)) {
			return Err(BuildSignersError::MissingPrivateKeys);
		}
		Ok(SignersContainer::build(keymap, &public_desc, wallet.secp_ctx()))
	}

	/// Returns an iterator for each unconfirmed transaction in the wallet.
	fn unconfirmed_txids(&self) -> impl Iterator<Item = Txid> {
		self.borrow().transactions().filter_map(|tx| {
			if tx.chain_position.is_unconfirmed() {
				Some(tx.tx_node.txid)
			} else {
				None
			}
		})
	}

	/// Returns an iterator for each unconfirmed transaction in the wallet, useful for syncing
	/// with bitcoin core.
	fn unconfirmed_txs(&self) -> impl Iterator<Item = Arc<Transaction>> {
		self.borrow().transactions().filter_map(|tx| {
			if tx.chain_position.is_unconfirmed() {
				Some(tx.tx_node.tx.clone())
			} else {
				None
			}
		})
	}

	/// Compute the wallet balance using our recursive trust model.
	fn trusted_balance(&self, min_confs: u32) -> TrustedBalance {
		let canon = TrustedCanonicalization::from_wallet(self.borrow(), min_confs);
		let mut trusted = Amount::ZERO;
		let mut untrusted = Amount::ZERO;
		for utxo in canon.list_unspent() {
			if utxo.is_trusted {
				trusted += utxo.txout.value;
			} else {
				untrusted += utxo.txout.value;
			}
		}
		TrustedBalance { trusted, untrusted }
	}

	/// Check if a transaction is fully owned by the wallet (all inputs spend
	/// wallet-owned outputs).
	fn is_fully_owned_tx(&self, txid: Txid) -> bool {
		let wallet = self.borrow();
		let graph = wallet.tx_graph();
		match graph.get_tx(txid) {
			Some(tx) => {
				tx.input.iter().all(|input| {
					let prev = input.previous_output;
					graph.get_tx(prev.txid)
						.and_then(|prev_tx| prev_tx.output.get(prev.vout as usize).cloned())
						.map(|out| wallet.is_mine(out.script_pubkey))
						.unwrap_or(false)
					})
			}, None => false
		}

	}

	/// Insert a checkpoint into the wallet.
	///
	/// It's advised to use this only when recovering a wallet with a birthday.
	fn set_checkpoint(&mut self, height: u32, hash: BlockHash) {
		let checkpoint = BlockId { height, hash };
		let wallet = self.borrow_mut();
		wallet.apply_update(bdk_wallet::Update {
			chain: Some(wallet.latest_checkpoint().insert(checkpoint)),
			..Default::default()
		}).expect("should work, might fail if tip is genesis");
	}

	/// Mark the keys used in the outputs of this tx as unused
	///
	/// Used to replaced removed `cancel_tx` function as per suggestion:
	/// <https://github.com/bitcoindevkit/bdk_wallet/pull/393>
	fn mark_output_keys_unused(&mut self, tx: &Transaction) {
		let wallet = self.borrow_mut();
		for txout in &tx.output {
			if let Some((keychain, index)) = wallet.spk_index().index_of_spk(txout.script_pubkey.clone()) {
				// NOTE: unmark_used will **not** make something unused if it has actually been used
				// by a tx in the tracker. It only removes the superficial marking.
				wallet.unmark_used(*keychain, *index);
			}
		}
	}

	fn make_signed_p2a_cpfp(
		&mut self,
		tx: &Transaction,
		fees: MakeCpfpFees,
		signers: &SignersContainer,
	) -> Result<Transaction, CpfpInternalError> {
		let wallet = self.borrow_mut();
		let (fee_anchor_point, fee_anchor_txout) = tx.fee_anchor()
			.ok_or_else(|| CpfpInternalError::NoFeeAnchor(tx.compute_txid()))?;

		// Since BDK doesn't support adding extra weight for fees, we have to loop to achieve the
		// effective fee rate and potential minimum fee we need.
		let parent_weight = tx.weight();
		let extra_fee_needed = parent_weight * fees.effective();

		// Since BDK doesn't allow tx without recipients, we add a drain output.
		let change_addr = wallet.next_unused_address(KEYCHAIN);

		// We will loop, constructing the transaction and signing it until we exceed the effective
		// fee rate and meet any minimum fee requirements
		let mut final_child_weight = Weight::ZERO;
		let mut fee_needed = extra_fee_needed;
		for i in 0..100 {
			// The change is this transaction's only output, so use a coin selection that
			// guarantees it stays above the dust limit.
			let mut b = wallet.build_tx()
				.coin_selection(WithGuaranteedChange(DefaultCoinSelectionAlgorithm::default()));
			b.only_witness_utxo();
			b.exclude_unconfirmed();
			b.version(3); // for 1p1c package relay, all inputs must be confirmed
			b.add_fee_anchor_spend(fee_anchor_point, fee_anchor_txout);
			b.drain_to(change_addr.address.script_pubkey());
			b.fee_absolute(fee_needed);

			// Attempt to create and sign the transaction
			let mut psbt = b.finish().map_err(|e| match e {
				CreateTxError::CoinSelection(e) => CpfpInternalError::InsufficientConfirmedFunds(e),
				_ => CpfpInternalError::Create(e),
			})?;
			#[allow(deprecated)]
			let opts = bdk_wallet::SignOptions {
				trust_witness_utxo: true,
				..Default::default()
			};
			let finalized = wallet.sign_with_signers(&mut psbt, &[signers], opts)
				.map_err(|e| CpfpInternalError::Signer(e))?;
			if !finalized {
				return Err(CpfpInternalError::FinalizeError("finalization failed".into()));
			}
			let tx = psbt.extract_tx()
				.map_err(|e| CpfpInternalError::Extract(e))?;
			assert!(tx.input.iter().any(|i| i.previous_output == fee_anchor_point),
				"Missing anchor spend, tx is {}", serialize_hex(&tx),
			);

			// We can finally check the fees and weight
			let tx_weight = tx.weight();
			let total_weight = tx_weight + parent_weight;
			if tx_weight != final_child_weight {
				// Since the weight changed, we can drop the transaction and recalculate the
				// required fee amount.
				wallet.mark_output_keys_unused(&tx);
				final_child_weight = tx_weight;
				fee_needed = fees.package_fee(parent_weight, tx_weight);
			} else {
				debug!("Created P2A CPFP with weight {} and fee {} in {} iterations",
					total_weight, fee_needed, i,
				);
				return Ok(tx);
			}
		}
		Err(CpfpInternalError::General("Reached max iterations".into()))
	}
}

#[cfg(test)]
mod test {
	use super::*;

	use bdk_wallet::KeychainKind;
	use bdk_wallet::chain::BlockId;
	use bdk_wallet::test_utils::{
		get_test_tr_single_sig, get_test_tr_with_taptree, get_test_wpkh, insert_checkpoint,
		receive_output, receive_output_in_latest_block, ReceiveTo,
	};
	use bitcoin::Network;
	use bitcoin::hashes::Hash;

	/// A wallet with two confirmed UTXOs of 1000 and 1001 sats.
	fn two_utxo_wallet() -> (Wallet, OutPoint) {
		let mut wallet = Wallet::create_single(get_test_wpkh())
			.network(Network::Regtest)
			.create_wallet_no_persist()
			.unwrap();
		insert_checkpoint(&mut wallet, BlockId { height: 1_000, hash: BlockHash::all_zeros() });
		let op1 = receive_output_in_latest_block(&mut wallet, Amount::from_sat(1_000));
		receive_output_in_latest_block(&mut wallet, Amount::from_sat(1_001));
		(wallet, op1)
	}

	/// Build the drain-only tx shape of a CPFP child: one mandatory input, an absolute fee it
	/// covers on its own, and the drain as sole output. The 1000-sat input minus the 900-sat fee
	/// leaves 100 sats: below the change script's dust limit, so default coin selection fails
	/// (`InsufficientFunds`) instead of pulling in the second UTXO.
	#[test]
	fn guaranteed_change_selection_rescues_sub_dust_change() {
		let (mut wallet, op1) = two_utxo_wallet();
		let change_spk = wallet.reveal_next_address(KeychainKind::External)
			.address.script_pubkey();
		let fee = Amount::from_sat(900);
		assert!(Amount::from_sat(100) < change_spk.minimal_non_dust(), "premise");

		let mut b = wallet.build_tx()
			.coin_selection(WithGuaranteedChange(DefaultCoinSelectionAlgorithm::default()));
		b.add_utxo(op1).unwrap();
		b.only_witness_utxo();
		b.drain_to(change_spk.clone());
		b.fee_absolute(fee);
		let psbt = b.finish().expect("both UTXOs cover fee + dust");

		let tx = &psbt.unsigned_tx;
		assert_eq!(tx.input.len(), 2, "must pull in the second UTXO");
		assert_eq!(tx.output.len(), 1);
		let change = tx.output[0].value;
		assert!(change >= change_spk.minimal_non_dust(), "change {} is dust", change);
		// The raised selection target must flow into the change, not the fee.
		assert_eq!(change, Amount::from_sat(2_001) - fee);
		assert_eq!(psbt.fee().unwrap(), fee);
	}

	/// When even the whole wallet can't leave a non-dust drain, selection must fail with
	/// [InsufficientFunds] instead of producing a dust (non-standard) output.
	#[test]
	fn guaranteed_change_selection_fails_when_change_can_only_be_dust() {
		let (mut wallet, op1) = two_utxo_wallet();
		let change_spk = wallet.reveal_next_address(KeychainKind::External)
			.address.script_pubkey();
		// Both UTXOs together hold 2001 sats; this fee leaves 101 sats, below the dust limit.
		let fee = Amount::from_sat(1_900);
		let dust = change_spk.minimal_non_dust();
		assert!(Amount::from_sat(101) < dust, "premise");

		let mut b = wallet.build_tx()
			.coin_selection(WithGuaranteedChange(DefaultCoinSelectionAlgorithm::default()));
		b.add_utxo(op1).unwrap();
		b.only_witness_utxo();
		b.drain_to(change_spk);
		b.fee_absolute(fee);

		match b.finish() {
			Err(CreateTxError::CoinSelection(e)) => {
				assert_eq!(e.needed, fee + dust, "needed must cover fee plus a non-dust drain");
				assert_eq!(e.available, Amount::from_sat(2_001), "available must be the whole wallet");
			},
			other => panic!("expected InsufficientFunds, got {:?}", other),
		}
	}

	/// When a single UTXO leaves non-dust change, no extra input should be pulled in.
	#[test]
	fn guaranteed_change_selection_no_extra_input_when_change_is_fine() {
		let (mut wallet, op1) = two_utxo_wallet();
		let change_spk = wallet.reveal_next_address(KeychainKind::External)
			.address.script_pubkey();
		let fee = Amount::from_sat(500);

		let mut b = wallet.build_tx()
			.coin_selection(WithGuaranteedChange(DefaultCoinSelectionAlgorithm::default()));
		b.add_utxo(op1).unwrap();
		b.only_witness_utxo();
		b.drain_to(change_spk.clone());
		b.fee_absolute(fee);
		let psbt = b.finish().unwrap();

		let tx = &psbt.unsigned_tx;
		assert_eq!(tx.input.len(), 1, "1000-sat input alone leaves non-dust change");
		assert_eq!(tx.output.len(), 1);
		assert_eq!(tx.output[0].script_pubkey, change_spk, "the only output is the change");
		assert_eq!(tx.output[0].value, Amount::from_sat(500));
		assert_eq!(psbt.fee().unwrap(), fee);
	}

	/// A wallet with two confirmed UTXOs (10k and 4k sats) and an unconfirmed 50k-sat one.
	fn mixed_confirmation_wallet() -> (Wallet, Vec<OutPoint>, OutPoint) {
		let mut wallet = Wallet::create_single(get_test_wpkh())
			.network(Network::Regtest)
			.create_wallet_no_persist()
			.unwrap();
		insert_checkpoint(&mut wallet, BlockId { height: 1_000, hash: BlockHash::all_zeros() });
		let confirmed = vec![
			receive_output_in_latest_block(&mut wallet, Amount::from_sat(10_000)),
			receive_output_in_latest_block(&mut wallet, Amount::from_sat(4_000)),
		];
		let unconfirmed = receive_output(&mut wallet, Amount::from_sat(50_000), ReceiveTo::Mempool(1));
		(wallet, confirmed, unconfirmed)
	}

	/// While confirmed funds cover the payment, the bigger unconfirmed
	/// UTXO must not be selected.
	#[test]
	fn prefer_confirmed_selection_ignores_unconfirmed_when_possible() {
		let (mut wallet, confirmed, unconfirmed) = mixed_confirmation_wallet();
		let recipient = wallet.reveal_next_address(KeychainKind::External)
			.address.script_pubkey();

		let mut b = wallet.build_tx()
			.coin_selection(PreferConfirmedCoinSelection(DefaultCoinSelectionAlgorithm::default()));
		b.add_recipient(recipient, Amount::from_sat(5_000));
		b.fee_rate(FeeRate::from_sat_per_vb(2).unwrap());
		let psbt = b.finish().expect("confirmed funds suffice");

		let inputs = psbt.unsigned_tx.input.iter()
			.map(|i| i.previous_output)
			.collect::<Vec<_>>();
		assert!(!inputs.is_empty());
		assert!(inputs.iter().all(|i| confirmed.contains(i)));
		assert!(!inputs.contains(&unconfirmed));
	}

	/// Once confirmed funds fall short, every confirmed UTXO is spent and
	/// the unconfirmed one tops up the difference.
	#[test]
	fn prefer_confirmed_selection_falls_back_to_unconfirmed() {
		let (mut wallet, confirmed, unconfirmed) = mixed_confirmation_wallet();
		let recipient = wallet.reveal_next_address(KeychainKind::External)
			.address.script_pubkey();

		let mut b = wallet.build_tx()
			.coin_selection(PreferConfirmedCoinSelection(DefaultCoinSelectionAlgorithm::default()));
		b.add_recipient(recipient, Amount::from_sat(30_000));
		b.fee_rate(FeeRate::from_sat_per_vb(2).unwrap());
		let psbt = b.finish().expect("all funds together suffice");

		let inputs = psbt.unsigned_tx.input.iter()
			.map(|i| i.previous_output)
			.collect::<Vec<_>>();
		for op in &confirmed {
			assert!(inputs.contains(op), "every confirmed UTXO must be spent");
		}
		assert!(inputs.contains(&unconfirmed), "unconfirmed UTXO must be pulled in");
	}

	#[test]
	fn build_signers_from_wallet_descriptor() {
		let (wallet, _) = two_utxo_wallet();
		let signers = wallet.build_signers(get_test_wpkh()).unwrap();
		assert_eq!(signers.signers().len(), 1);
	}

	#[test]
	fn build_signers_rejects_public_descriptor() {
		let (wallet, _) = two_utxo_wallet();
		let public = wallet.public_descriptor(KEYCHAIN).clone();
		match wallet.build_signers(public) {
			Err(BuildSignersError::MissingPrivateKeys) => {},
			other => panic!("expected MissingPrivateKeys, got {:?}", other),
		}
	}

	#[test]
	fn build_signers_rejects_partly_public_descriptor() {
		let wallet = Wallet::create_single(get_test_tr_with_taptree())
			.network(Network::Regtest)
			.create_wallet_no_persist()
			.unwrap();
		match wallet.build_signers(get_test_tr_with_taptree()) {
			Err(BuildSignersError::MissingPrivateKeys) => {},
			other => panic!("expected MissingPrivateKeys, got {:?}", other),
		}
	}

	#[test]
	fn build_signers_rejects_other_descriptor() {
		let (wallet, _) = two_utxo_wallet();
		match wallet.build_signers(get_test_tr_single_sig()) {
			Err(BuildSignersError::DescriptorMismatch) => {},
			other => panic!("expected DescriptorMismatch, got {:?}", other),
		}
	}
}

impl WalletExt for Wallet {}
