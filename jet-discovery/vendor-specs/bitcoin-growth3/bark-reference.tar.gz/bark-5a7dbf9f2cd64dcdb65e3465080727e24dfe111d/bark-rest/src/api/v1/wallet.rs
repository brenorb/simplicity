use std::str::FromStr;
use std::sync::Arc;
use std::time::Duration;

use anyhow::Context;
use axum::extract::{Path, Query, State};
use axum::routing::{get, post};
use axum::{Json, Router, debug_handler};

use bitcoin::Amount;
use bitcoin_ext::BlockHeight;
use utoipa::OpenApi;

use ark::VtxoId;
use ark::ProtocolEncoding;

use bark::{ImportVtxoError, LightningSendOptions};
use bark::payment_request::PaymentInitOutput;
use bark::round::RoundStatus;
use bark::subsystem::RoundMovement;
use bark::vtxo::VtxoFilter;
use bark_json::web::PendingRoundInfo;

use crate::{ServerState, ServerWallet, error};
use crate::error::{ContextExt, HandlerResult, badarg, not_found, unprocessable};

pub fn router() -> Router<Arc<ServerState>> {
	#[allow(deprecated)]
	Router::new()
		.route("/", get(wallet_exists).post(create_wallet).delete(wallet_delete))
		.route("/connected", get(connected))
		.route("/create", post(create_wallet))
		.route("/mnemonic", get(mnemonic))
		.route("/ark-info", get(ark_info))
		.route("/debug-info", get(debug_info))
		.route("/next-round", get(next_round))
		.route("/addresses/next", post(address))
		.route("/addresses/index/{index}", get(peek_address))
		.route("/bip321", post(bip321_uri))
		.route("/balance", get(balance))
		.route("/vtxos", get(vtxos))
		.route("/vtxos/{id}", get(get_vtxo))
		.route("/vtxos/{id}/encoded", get(get_vtxo_encoded))
		.route("/movements", get(movements))
		.route("/history", get(history))
		.route("/send", post(send))
		.route("/refresh/vtxos", post(refresh_vtxos))
		.route("/refresh/delegated/vtxos", post(refresh_delegated))
		.route("/refresh/all", post(refresh_all))
		.route("/refresh/counterparty", post(refresh_counterparty))
		.route("/offboard/vtxos", post(offboard_vtxos))
		.route("/offboard/all", post(offboard_all))
		.route("/send-onchain", post(send_onchain))
		.route("/rounds", get(pending_rounds))
		.route("/sync", post(sync))
		.route("/sync/mailbox", post(sync_mailbox))
		.route("/import-vtxo", post(import_vtxo))
}

#[derive(OpenApi)]
#[openapi(
	paths(
		wallet_exists,
		wallet_delete,
		connected,
		create_wallet,
		mnemonic,
		ark_info,
		debug_info,
		next_round,
		address,
		peek_address,
		bip321_uri,
		balance,
		vtxos,
		get_vtxo,
		get_vtxo_encoded,
		movements,
		history,
		send,
		refresh_vtxos,
		refresh_delegated,
		refresh_all,
		refresh_counterparty,
		offboard_vtxos,
		offboard_all,
		send_onchain,
		pending_rounds,
		sync,
		sync_mailbox,
		import_vtxo,
	),
	components(schemas(
		bark_json::web::ArkAddressResponse,
		bark_json::web::Bip321UriRequest,
		bark_json::web::Bip321UriQuery,
		bark_json::web::Bip321UriResponse,
		bark_json::web::WalletExistsResponse,
		bark_json::web::WalletDeleteRequest,
		bark_json::web::WalletDeleteResponse,
		bark_json::web::ConnectedResponse,
		bark_json::web::CreateWalletRequest,
		bark_json::web::CreateWalletResponse,
		bark_json::web::MnemonicResponse,
		bark_json::cli::ArkInfo,
		bark_json::cli::DebugInfo,
		bark_json::cli::NextRoundStart,
		bark_json::web::VtxosQuery,
		bark_json::cli::Balance,
		bark_json::primitives::WalletVtxoInfo,
		bark_json::web::EncodedVtxoResponse,
		bark_json::movements::Movement,
		bark_json::web::SendRequest,
		bark_json::web::PaymentMethodKind,
		bark_json::web::SendResponse,
		bark_json::web::RefreshRequest,
		bark_json::web::DelegatedRefreshRequest,
		bark_json::web::OffboardVtxosRequest,
		bark_json::web::OffboardAllRequest,
		bark_json::web::ImportVtxoRequest,
		bark_json::web::MailboxSyncResponse,
		bark_json::web::PendingRoundInfo,
		bark_json::cli::RoundStatus,
		error::InternalServerError,
		error::NotFoundError,
		error::BadRequestError,
	)),
	tags(
		(name = "wallet", description = "Manage Ark balances and VTXOs, send payments via Ark, LN, and on-chain."),
	)
)]
pub struct WalletApiDoc;

#[utoipa::path(
	get,
	path = "/connected",
	summary = "Check server connection",
	responses(
		(status = 200, description = "Returns whether the wallet is connected to an Ark server", body = bark_json::web::ConnectedResponse),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Checks whether the wallet has an active connection to the Ark server. \
		Returns `true` if the wallet can reach the server and retrieve its configuration, \
		`false` otherwise. The background daemon checks the server connection every second, \
		so this reflects the most recent known state.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn connected(
	State(state): State<Arc<ServerState>>,
) -> HandlerResult<Json<bark_json::web::ConnectedResponse>> {
	let wallet = state.require_wallet()?;
	Ok(axum::Json(bark_json::web::ConnectedResponse {
		connected: wallet.ark_info().await?.is_some(),
	}))
}

#[utoipa::path(
	get,
	path = "",
	responses(
		(status = 200, description = "Wallet existence status", body = bark_json::web::WalletExistsResponse),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	tag = "wallet"
)]
#[debug_handler]
pub async fn wallet_exists(
	State(state): State<Arc<ServerState>>,
) -> HandlerResult<Json<bark_json::web::WalletExistsResponse>> {
	let wallet = state.wallet.read();
	Ok(Json(bark_json::web::WalletExistsResponse {
		fingerprint: wallet.as_ref().map(|w| w.fingerprint().to_string()),
	}))
}

#[utoipa::path(
	delete,
	path = "",
	summary = "Delete the wallet",
	request_body = bark_json::web::WalletDeleteRequest,
	responses(
		(status = 200, description = "Wallet deletion status", body = bark_json::web::WalletDeleteResponse),
		(status = 400, description = "Invalid request", body = error::BadRequestError),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Stops the wallet and removes every wallet file from the datadir; barkd's \
		own files survive. Requires `dangerous: true` and, while a wallet is loaded, the \
		wallet's fingerprint. With no wallet loaded, the call still removes any leftover \
		wallet files. A retry completes an interrupted deletion.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn wallet_delete(
	State(state): State<Arc<ServerState>>,
	Json(req): Json<bark_json::web::WalletDeleteRequest>,
) -> HandlerResult<Json<bark_json::web::WalletDeleteResponse>> {
	if !req.dangerous {
		badarg!("deletion not confirmed: set dangerous=true");
	}

	let Some(hook) = state.on_wallet_delete.as_ref() else {
		badarg!("No wallet deletion hook configured");
	};

	let _lifecycle = state.wallet_lifecycle.lock().await;

	// Take the wallet out of the state before the wipe, so no new request
	// reaches it, and stop its daemon: a daemon task that runs during the
	// wipe can re-create wallet files.
	let wallet = {
		let mut guard = state.wallet.write();
		if let Some(w) = guard.as_ref() {
			if w.fingerprint().to_string() != req.fingerprint {
				badarg!("Fingerprint does not match the loaded wallet");
			}
		}
		guard.take()
	};
	let fingerprint = wallet.as_ref().map(|w| w.fingerprint().to_string());
	let loaded = wallet.is_some();
	if let Some(wallet) = wallet {
		if let Err(e) = wallet.stop_wait().await {
			log::warn!("Error stopping wallet tasks during delete: {:#}", e);
		}
	}

	// The wipe also runs when no wallet is loaded: it completes a delete
	// that failed midway and removes wallet files a failed create left.
	hook().await.context("Couldn't delete wallet")?;

	let message = if loaded {
		"Wallet deleted"
	} else {
		"No wallet was loaded; wiped any leftover wallet files"
	};
	Ok(Json(bark_json::web::WalletDeleteResponse {
		deleted: loaded,
		fingerprint,
		message: message.to_string(),
	}))
}


#[utoipa::path(
	post,
	path = "/create",
	summary = "Create a wallet",
	responses(
		(status = 200, description = "Wallet created successfully", body = bark_json::web::CreateWalletResponse),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Creates a new wallet with the specified Ark server and chain source \
		configuration. Fails if a wallet already exists. Returns the wallet fingerprint \
		on success.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn create_wallet(
	State(state): State<Arc<ServerState>>,
	Json(req): Json<bark_json::web::CreateWalletRequest>,
) -> HandlerResult<Json<bark_json::web::CreateWalletResponse>> {
	let _lifecycle = state.wallet_lifecycle.lock().await;

	if state.wallet.read().is_some() {
		badarg!("Wallet already set");
	}

	if let Some(on_wallet_create) = state.on_wallet_create.as_ref() {
		let wallet = on_wallet_create(req).await?;
		let wallet = ServerWallet::new(wallet, state.shutdown.clone());

		let fingerprint = wallet.fingerprint().to_string();
		let _ = state.wallet.write().insert(wallet);

		Ok(axum::Json(bark_json::web::CreateWalletResponse { fingerprint }))
	} else {
		badarg!("No wallet creation hook set");
	}
}

#[utoipa::path(
	get,
	path = "/mnemonic",
	summary = "Get wallet mnemonic",
	responses(
		(status = 200, description = "Returns the wallet's BIP-39 mnemonic phrase", body = bark_json::web::MnemonicResponse),
		(status = 404, description = "Mnemonic retrieval is disabled", body = error::NotFoundError),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Returns the BIP-39 mnemonic phrase backing the wallet. Returns 404 when \
		mnemonic exposure is disabled. Exposure is off by default; the endpoint returns \
		404 unless barkd is started with the `--expose-mnemonic` flag.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn mnemonic(
	State(state): State<Arc<ServerState>>,
) -> HandlerResult<Json<bark_json::web::MnemonicResponse>> {
	let Some(hook) = state.on_get_mnemonic.as_ref() else {
		not_found!(Vec::<String>::new(), "Mnemonic endpoint is disabled");
	};
	let mnemonic = hook().await?;
	Ok(axum::Json(bark_json::web::MnemonicResponse { mnemonic }))
}

#[utoipa::path(
	get,
	path = "/ark-info",
	summary = "Get Ark server info",
	responses(
		(status = 200, description = "Returns the Ark info", body = bark_json::cli::ArkInfo),
		(status = 404, description = "Wallet not connected to an Ark server", body = error::NotFoundError),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Returns the Ark server's configuration parameters, including network, \
		public key, round interval, VTXO expiry and exit deltas, fee settings, and \
		Lightning support details.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn ark_info(
	State(state): State<Arc<ServerState>>,
) -> HandlerResult<Json<bark_json::cli::ArkInfo>> {
	let wallet = state.require_wallet()?;
	let ark_info = wallet.ark_info().await?;

	match ark_info {
		Some(ark_info) => Ok(axum::Json(ark_info.into())),
		None => not_found!(["ark server"], "Wallet not connected to an Ark server"),
	}
}

#[utoipa::path(
	get,
	path = "/debug-info",
	summary = "Get wallet debug info",
	responses(
		(status = 200, description = "Returns the wallet debug info", body = bark_json::cli::DebugInfo),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Returns wallet information that helps to debug issues: the bitcoin \
		network, the ID of the wallet's server mailbox and the xpub from which all VTXO \
		keypairs are derived.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn debug_info(
	State(state): State<Arc<ServerState>>,
) -> HandlerResult<Json<bark_json::cli::DebugInfo>> {
	let wallet = state.require_wallet()?;
	let info = wallet.debug_info().await
		.context("Failed to get wallet debug info")?;

	Ok(axum::Json(info.into()))
}

#[utoipa::path(
	get,
	path = "/next-round",
	summary = "Get next round time",
	responses(
		(status = 200, description = "Returns the next round start time", body = bark_json::cli::NextRoundStart),
		(status = 404, description = "Wallet not connected to an Ark server", body = error::NotFoundError),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Queries the Ark server for the next scheduled round start time and returns \
		it in RFC 3339 format.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn next_round(
	State(state): State<Arc<ServerState>>,
) -> HandlerResult<Json<bark_json::cli::NextRoundStart>> {
	let wallet = state.require_wallet()?;
	let time = wallet.next_round_start_time().await?;
	Ok(axum::Json(bark_json::cli::NextRoundStart { start_time: time.into() }))
}

#[utoipa::path(
	post,
	path = "/addresses/next",
	summary = "Generate Ark address",
	responses(
		(status = 200, description = "Returns the Ark address", body = bark_json::web::ArkAddressResponse),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Generates a new Ark receiving address. Each call returns the next unused \
		address from the wallet's HD keychain.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn address(
	State(state): State<Arc<ServerState>>,
) -> HandlerResult<Json<bark_json::web::ArkAddressResponse>> {
	let wallet = state.require_wallet()?;
	let ark_address = wallet.new_address().await
		.context("Failed to generate new address")?;

	Ok(axum::Json(bark_json::web::ArkAddressResponse {
		address: ark_address.to_string(),
	}))
}

#[utoipa::path(
	get,
	path = "/addresses/index/{index}",
	summary = "Get Ark address by index",
	params(
		("index" = u32, Path, description = "Index for the address.")
	),
	responses(
		(status = 200, description = "Returns the Ark address", body = bark_json::web::ArkAddressResponse),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Returns a previously generated Ark address by its derivation index. Only \
		addresses that have already been generated are available.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn peek_address(
	State(state): State<Arc<ServerState>>,
	Path(index): Path<u32>,
) -> HandlerResult<Json<bark_json::web::ArkAddressResponse>> {
	let wallet = state.require_wallet()?;
	let ark_address = wallet.peek_address(index).await
		.with_context(|| format!("Failed to get address at index {}", index))?;

	Ok(axum::Json(bark_json::web::ArkAddressResponse {
		address: ark_address.to_string(),
	}))
}

#[utoipa::path(
	post,
	path = "/bip321",
	summary = "Build a BIP 321 payment URI",
	params(
		("uppercase" = Option<bool>, Query, description = "Upper-case the returned `bip321` URI for compact QR encoding. Defaults to false. Fails with 400 if the URI carries case-sensitive data (a label, message, or base58 address)."),
	),
	request_body = bark_json::web::Bip321UriRequest,
	responses(
		(status = 200, description = "Returns the BIP 321 URI and its destinations", body = bark_json::web::Bip321UriResponse),
		(status = 400, description = "Requested an upper-case URI that carries case-sensitive data", body = error::BadRequestError),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Builds a single BIP 321 `bitcoin:` URI bundling multiple ways to receive \
		the same payment, so one call prepares everything needed for an incoming payment. \
		A fresh Ark address is always included. When `amount_sat` is given, a BOLT11 invoice \
		for that amount is generated and the amount is embedded in the URI. When `onchain` is \
		`true`, a fresh on-chain address is added (placed in the URI body on mainnet, as a \
		`tb=` parameter on test networks). Set the `uppercase` query parameter to upper-case \
		the `bip321` URI so QR encoders can use the compact alphanumeric mode; this fails if \
		the URI carries case-sensitive data. The individual `ark`, `bolt11`, and `onchain` \
		destinations are always returned in their natural case for direct use.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn bip321_uri(
	State(state): State<Arc<ServerState>>,
	Query(query): Query<bark_json::web::Bip321UriQuery>,
	Json(body): Json<bark_json::web::Bip321UriRequest>,
) -> HandlerResult<Json<bark_json::web::Bip321UriResponse>> {
	let mut wallet = state.require_wallet()?;

	let mut builder = wallet.bip321_uri();
	if let Some(amount_sat) = body.amount_sat {
		builder = builder.amount_sat(amount_sat);
	}
	if let Some(label) = body.label {
		builder = builder.label(label);
	}
	if let Some(message) = body.message {
		builder = builder.message(message);
	}

	// The builder borrows the onchain wallet for its whole lifetime, so the
	// write guard must outlive the build() call.
	let uri = if body.onchain.unwrap_or(false) {
		let onchain = state.require_onchain()?;
		let mut onchain = onchain.write().await;
		builder.onchain_wallet(&mut *onchain).build().await
			.context("Failed to build BIP 321 URI")?
	} else {
		builder.build().await
			.context("Failed to build BIP 321 URI")?
	};

	let bip321 = if query.uppercase.unwrap_or(false) {
		uri.checked_uppercase()
			.badarg("cannot upper-case the URI: it carries a label, message, or base58 address")?
	} else {
		uri.to_string()
	};

	Ok(axum::Json(bark_json::web::Bip321UriResponse {
		ark: uri.extensions().ark().first().map(|a| a.inner().to_string()),
		bolt11: uri.lightning().first().map(|i| i.inner().to_string()),
		// onchain addresses live in the URI body on mainnet and in `tb=` on test networks
		onchain: uri.address().map(|a| a.to_string())
			.or_else(|| uri.tb().first().map(|a| a.inner().to_string())),
		bip321,
	}))
}

#[utoipa::path(
	get,
	path = "/balance",
	summary = "Get wallet balance",
	responses(
		(status = 200, description = "Returns the wallet balance", body = bark_json::cli::Balance),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Returns the wallet balance broken down by category: spendable sats \
		available for immediate use, sats pending in an Ark round, sats locked in outgoing \
		or incoming Lightning payments, sats awaiting board confirmation, and sats in a \
		pending exit. The balance is computed from local state, which the background daemon \
		keeps reasonably fresh (Lightning syncs every second, mailbox and boards every \
		30 seconds). For the most up-to-date figures, call `sync` before this endpoint.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn balance(
	State(state): State<Arc<ServerState>>,
) -> HandlerResult<Json<bark_json::cli::Balance>> {
	let wallet = state.require_wallet()?;
	let balance = wallet.balance().await
		.context("Failed to get wallet balance")?;

	Ok(axum::Json(balance.into()))
}

#[utoipa::path(
	get,
	path = "/vtxos",
	summary = "List VTXOs",
	params(
		("all" = Option<bool>, Query, description = "Return all VTXOs regardless of their state. If not provided, returns only non-spent VTXOs.")
	),
	responses(
		(status = 200, description = "Returns the wallet VTXOs", body = Vec<bark_json::primitives::WalletVtxoInfo>),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Returns VTXOs held by the wallet, including their state and expiry \
		information. By default returns only non-spent VTXOs. Set `all=true` to include \
		all VTXOs regardless of state.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn vtxos(
	State(state): State<Arc<ServerState>>,
	Query(query): Query<bark_json::web::VtxosQuery>,
) -> HandlerResult<Json<Vec<bark_json::primitives::WalletVtxoInfo>>> {
	let wallet = state.require_wallet()?;
	let wallet_vtxos = if query.all.unwrap_or(false) {
		wallet.all_vtxos().await.context("Failed to get all VTXOs")?
	} else {
		wallet.vtxos().await.context("Failed to get VTXOs")?
	};

	let vtxo_infos = wallet_vtxos.iter()
		.map(bark_json::primitives::WalletVtxoInfo::from)
		.collect();

	Ok(axum::Json(vtxo_infos))
}

#[utoipa::path(
	get,
	path = "/vtxos/{id}",
	summary = "Get VTXO detail",
	params(
		("id" = String, Path, description = "VTXO identifier formatted as `txid:vout`.")
	),
	responses(
		(status = 200, description = "Returns the VTXO detail", body = bark_json::primitives::WalletVtxoInfo),
		(status = 400, description = "Invalid VTXO id", body = error::BadRequestError),
		(status = 404, description = "VTXO not found", body = error::NotFoundError),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Returns detail for a single VTXO. To get the hex-encoded serialization \
		use `GET /vtxos/{id}/encoded`.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn get_vtxo(
	State(state): State<Arc<ServerState>>,
	Path(id): Path<String>,
) -> HandlerResult<Json<bark_json::primitives::WalletVtxoInfo>> {
	let wallet = state.require_wallet()?;
	let vtxo_id = VtxoId::from_str(&id).badarg("Invalid VTXO id")?;
	let wallet_vtxo = wallet.get_vtxo_by_id(vtxo_id).await
		.not_found([vtxo_id], "VTXO not found")?;

	Ok(axum::Json((&wallet_vtxo).into()))
}

#[utoipa::path(
	get,
	path = "/vtxos/{id}/encoded",
	summary = "Get encoded VTXO",
	params(
		("id" = String, Path, description = "VTXO identifier formatted as `txid:vout`.")
	),
	responses(
		(status = 200, description = "Returns the hex-encoded serialized VTXO", body = bark_json::web::EncodedVtxoResponse),
		(status = 400, description = "Invalid VTXO id", body = error::BadRequestError),
		(status = 404, description = "VTXO not found", body = error::NotFoundError),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Returns the hex-encoded serialization of a VTXO. The `encoded` field \
		can be passed to `POST /wallet/import-vtxo` to re-import this VTXO.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn get_vtxo_encoded(
	State(state): State<Arc<ServerState>>,
	Path(id): Path<String>,
) -> HandlerResult<Json<bark_json::web::EncodedVtxoResponse>> {
	let wallet = state.require_wallet()?;
	let vtxo_id = VtxoId::from_str(&id).badarg("Invalid VTXO id")?;
	let vtxo = wallet.get_full_vtxo(vtxo_id).await
		.not_found([vtxo_id], "VTXO not found")?;

	let encoded = bark_json::primitives::EncodedVtxo(vtxo.serialize_hex());
	Ok(axum::Json(bark_json::web::EncodedVtxoResponse { encoded }))
}

#[utoipa::path(
	get,
	path = "/movements",
	summary = "List movements (deprecated)",
	responses(
		(status = 200, description = "Returns the wallet movements", body = Vec<bark_json::movements::Movement>),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Deprecated: Use history instead",
	tag = "wallet",
)]
#[debug_handler]
#[deprecated(note = "Use `history` instead")]
pub async fn movements(
	State(state): State<Arc<ServerState>>,
) -> HandlerResult<Json<Vec<bark_json::movements::Movement>>> {
	let wallet = state.require_wallet()?;
	#[allow(deprecated)]
	let movements = wallet.movements().await.context("Failed to get movements")?;

	let json_movements = movements
		.into_iter()
		.map(|m| bark_json::movements::Movement::try_from(m)
			.context("Failed to convert movement to JSON")
		).collect::<Result<Vec<_>, _>>()?;

	Ok(axum::Json(json_movements))
}

#[utoipa::path(
	get,
	path = "/history",
	summary = "Get wallet history (deprecated)",
	responses(
		(status = 200, description = "Returns the wallet history", body = Vec<bark_json::movements::Movement>),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Deprecated: use `GET /api/v1/history` instead.",
	tag = "wallet"
)]
#[debug_handler]
#[deprecated(note = "Use `GET /api/v1/history` instead")]
pub async fn history(
	state: State<Arc<ServerState>>,
) -> HandlerResult<Json<Vec<bark_json::movements::Movement>>> {
	crate::api::v1::history::list(state, axum::extract::Query(Default::default())).await
}

#[utoipa::path(
	get,
	path = "/rounds",
	summary = "List round participations",
	responses(
		(status = 200, description = "Returns the wallet pending rounds", body = Vec<bark_json::web::PendingRoundInfo>),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Returns all active round participations and their current status. A round \
		participation is created when you call one of the `refresh` endpoints and persists \
		until the round's funding transaction is confirmed on-chain (2 confirmations on \
		mainnet, 1 on testnet). The list can contain multiple entries—for example, a \
		previous round awaiting on-chain confirmation alongside a newly submitted round \
		waiting for the next server round to start. Confirmed and failed rounds are \
		removed automatically by the background daemon.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn pending_rounds(
	State(state): State<Arc<ServerState>>,
) -> HandlerResult<Json<Vec<bark_json::web::PendingRoundInfo>>> {
	let wallet = state.require_wallet()?;

	let round_state_ids = wallet.pending_round_state_ids().await
		.context("Failed to get pending rounds")?;
	let mut infos = Vec::with_capacity(round_state_ids.len());
	for id in round_state_ids {
		let Some(mut round) = wallet.lock_wait_round_state(id).await?
		else {
			continue;
		};

		let sync = round.state_mut().sync(&wallet).await;
		infos.push(PendingRoundInfo::new(&round, sync));
	}
	Ok(axum::Json(infos))
}

#[utoipa::path(
	post,
	path = "/send",
	summary = "Send a payment",
	request_body = bark_json::web::SendRequest,
	responses(
		(status = 200, description = "Payment sent successfully", body = bark_json::web::SendResponse),
		(status = 400, description = "The destination is not a valid payment string, has no \
			valid payment method, or the request lacks a required amount", body = error::BadRequestError),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Sends a payment to the specified destination. Accepts \
		an Ark address, BOLT11 invoice, BOLT12 offer, Lightning address, LNURL, bitcoin \
		address, or BIP 321 URI. When the destination offers several payment methods, \
		`method` picks the kind to pay with; without it the wallet picks Ark, then \
		Lightning, then on-chain. Ark address payments \
		are settled instantly via an out-of-round (arkoor) transaction. The `amount_sat` field \
		is required unless the destination carries an amount. Comments are only supported \
		for Lightning addresses and LNURL.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn send(
	State(state): State<Arc<ServerState>>,
	Json(body): Json<bark_json::web::SendRequest>,
) -> HandlerResult<Json<bark_json::web::SendResponse>> {
	let wallet = state.require_wallet()?;

	let request = match wallet.parse_payment_request(&body.destination).await {
		Ok(request) => request,
		Err(e) => badarg!("invalid destination: {:#}", e),
	};

	let option = match body.method {
		Some(kind) => {
			let valid = request.options.iter().filter(|o| o.errors.is_empty());
			match valid.clone().find(|o| kind.matches(&o.method)) {
				Some(option) => option,
				None => {
					let methods = valid.map(|o| o.method.type_str()).collect::<Vec<_>>();
					badarg!("no valid {} payment method, valid methods are [{}]",
						kind, methods.join(", "));
				},
			}
		},
		None => match request.default_option() {
			Some(option) => option,
			None => {
				let problems = request.options.iter()
					.map(|o| {
						let errors = o.errors.iter().map(|e| e.to_string()).collect::<Vec<_>>();
						format!("{} ({})", o.method.type_str(), errors.join(", "))
					})
					.collect::<Vec<_>>();
				badarg!("no valid payment method: {}", problems.join(", "));
			},
		},
	};
	let method = &option.method;

	let amount = body.amount_sat.map(Amount::from_sat).or(request.amount);
	if amount.is_none() && method.requires_amount() {
		badarg!("amount is required for {}", method.type_str());
	}
	if body.comment.is_some() && !method.supports_comment() {
		badarg!("comment is not supported for {}", method.type_str());
	}

	let opts = LightningSendOptions::default()
		.retry_for(body.retry_for_secs.map(Duration::from_secs));
	let output = wallet.send_payment_with(method, amount, body.comment, opts).await?;

	let (message, payment_hash) = match output {
		PaymentInitOutput::Lightning(invoice) => {
			("Payment sent successfully".to_string(), Some(invoice.payment_hash()))
		},
		PaymentInitOutput::Ark(_) => ("Payment sent successfully".to_string(), None),
		PaymentInitOutput::Onchain(txid) => {
			(format!("Payment sent successfully in transaction {}", txid), None)
		},
	};
	Ok(axum::Json(bark_json::web::SendResponse { message, payment_hash }))
}

#[utoipa::path(
	post,
	path = "/refresh/vtxos",
	summary = "Refresh specific VTXOs",
	request_body = bark_json::web::RefreshRequest,
	responses(
		(status = 200, description = "Returns the refresh result", body = bark_json::web::PendingRoundInfo),
		(status = 400, description = "No VTXO IDs provided, or one of the provided VTXO \
			IDs is invalid", body = error::BadRequestError),
		(status = 404, description = "One the VTXOs wasn't found", body = error::NotFoundError),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Registers the specified VTXOs for refresh in the next Ark round. The \
		input VTXOs are locked immediately and will be forfeited once the round completes, \
		yielding new VTXOs with a fresh expiry. The background daemon automatically \
		participates in the round and progresses it to completion. Use the `rounds` \
		endpoint to track progress.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn refresh_vtxos(
	State(state): State<Arc<ServerState>>,
	Json(body): Json<bark_json::web::RefreshRequest>,
) -> HandlerResult<Json<bark_json::web::PendingRoundInfo>> {
	let wallet = state.require_wallet()?;

	if body.vtxos.is_empty() {
		badarg!("No VTXO IDs provided");
	}

	let vtxo_ids = body.vtxos
		.into_iter()
		.map(|s| ark::VtxoId::from_str(&s).badarg("Invalid VTXO id"))
		.collect::<Result<Vec<_>, _>>()?;

	let participation = wallet
		.build_refresh_participation(vtxo_ids).await
		.context("Failed to build round participation")?;

	match participation {
		Some(participation) => {
			let mut round = wallet
				.join_next_round(participation, Some(RoundMovement::Refresh)).await
				.context("Failed to store round participation")?;

			let sync = round.state_mut().sync(&wallet).await;
			Ok(axum::Json(PendingRoundInfo::new(&round, sync)))
		}
		None => {
			badarg!("No VTXOs to refresh");
		}
	}
}

#[utoipa::path(
	post,
	path = "/refresh/delegated/vtxos",
	summary = "Refresh VTXOs in delegated mode",
	request_body = bark_json::web::DelegatedRefreshRequest,
	responses(
		(status = 200, description = "Returns the refresh result", body = bark_json::web::PendingRoundInfo),
		(status = 400, description = "No VTXO IDs provided, or one of the provided VTXO \
			IDs is invalid", body = error::BadRequestError),
		(status = 404, description = "One the VTXOs wasn't found", body = error::NotFoundError),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Registers the specified VTXOs for refresh as a delegated participation: \
		the wallet hands the server a signed participation and the server carries it through \
		the round, so the wallet doesn't need to follow the round interactively. The input \
		VTXOs are locked immediately and will be forfeited once the round completes, yielding \
		new VTXOs with a fresh expiry.\n\n\
		Set `height` to schedule the refresh for a future block height: the refresh fee is \
		priced at that height and the server includes the participation in the first round \
		once the chain tip reaches it. When `height` is omitted, the participation is \
		eligible for the next round. Use the `rounds` endpoint to track progress.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn refresh_delegated(
	State(state): State<Arc<ServerState>>,
	Json(body): Json<bark_json::web::DelegatedRefreshRequest>,
) -> HandlerResult<Json<bark_json::web::PendingRoundInfo>> {
	let wallet = state.require_wallet()?;

	if body.vtxos.is_empty() {
		badarg!("No VTXO IDs provided");
	}

	let vtxo_ids = body.vtxos
		.into_iter()
		.map(|s| ark::VtxoId::from_str(&s).badarg("Invalid VTXO id"))
		.collect::<Result<Vec<_>, _>>()?;

	let round = match body.height {
		Some(height) => wallet.refresh_vtxos_scheduled(vtxo_ids, BlockHeight::new(height)).await
			.context("Failed to store round participation")?,
		None => wallet.refresh_vtxos_delegated(vtxo_ids).await
			.context("Failed to store round participation")?,
	};

	match round {
		Some(round) => Ok(axum::Json(PendingRoundInfo::new(&round, Ok(RoundStatus::Pending)))),
		None => badarg!("No VTXOs to refresh"),
	}
}

#[utoipa::path(
	post,
	path = "/refresh/all",
	summary = "Refresh all VTXOs",
	responses(
		(status = 200, description = "Returns the refresh result", body = bark_json::web::PendingRoundInfo),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Registers all spendable VTXOs for refresh in the next Ark round. The \
		input VTXOs are locked immediately and will be forfeited once the round completes, \
		yielding new VTXOs with a fresh expiry. The background daemon automatically \
		participates in the round and progresses it to completion. Use the `rounds` \
		endpoint to track progress.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn refresh_all(
	State(state): State<Arc<ServerState>>,
) -> HandlerResult<Json<bark_json::web::PendingRoundInfo>> {
	let wallet = state.require_wallet()?;

	let vtxos = wallet
		.spendable_vtxos().await
		.context("Failed to get spendable VTXOs")?;

	let participation = wallet
		.build_refresh_participation(vtxos).await
		.context("Failed to build round participation")?;

	match participation {
		Some(participation) => {
			let mut round = wallet
				.join_next_round(participation, Some(RoundMovement::Refresh)).await
				.context("Failed to store round participation")?;

			let sync = round.state_mut().sync(&wallet).await;
			Ok(axum::Json(PendingRoundInfo::new(&round, sync)))
		}
		None => {
			badarg!("No VTXOs to refresh");
		}
	}
}

#[utoipa::path(
	post,
	path = "/refresh/counterparty",
	summary = "Refresh received VTXOs",
	responses(
		(status = 200, description = "Returns the refresh result", body = bark_json::web::PendingRoundInfo),
		(status = 404, description = "There is no VTXO to refresh", body = error::NotFoundError),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Registers all out-of-round VTXOs held by the wallet for refresh in the \
		next Ark round. Refreshing replaces out-of-round VTXOs under arkoor trust \
		assumptions with trustless, in-round VTXOs. Out-of-round VTXOs whose entire \
		transaction chain originates from your own in-round VTXOs are excluded. The \
		background daemon automatically participates in the round and progresses it \
		to completion. Use the `rounds` endpoint to track progress.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn refresh_counterparty(
	State(state): State<Arc<ServerState>>,
) -> HandlerResult<Json<bark_json::web::PendingRoundInfo>> {
	let wallet = state.require_wallet()?;

	let filter = VtxoFilter::new(&wallet).counterparty();
	let vtxos = wallet
		.spendable_vtxos_with(&filter).await
		.context("Failed to get VTXOs")?;

	let participation = wallet
		.build_refresh_participation(vtxos).await
		.context("Failed to build round participation")?;

	match participation {
		Some(participation) => {
			let mut round = wallet
				.join_next_round(participation, Some(RoundMovement::Refresh)).await
				.context("Failed to store round participation")?;

			let sync = round.state_mut().sync(&wallet).await;
			Ok(axum::Json(PendingRoundInfo::new(&round, sync)))
		}
		None => {
			not_found!(Vec::<String>::new(), "No VTXO to refresh");
		}
	}
}

#[utoipa::path(
	post,
	path = "/offboard/vtxos",
	summary = "Offboard specific VTXOs",
	request_body = bark_json::web::OffboardVtxosRequest,
	responses(
		(status = 200, description = "Returns the offboard transaction id and the movement id",
			body = bark_json::cli::OffboardResult),
		(status = 400, description = "No VTXO IDs provided, or one of the provided \
			VTXO IDs is invalid, or destination address is invalid", body = error::BadRequestError),
		(status = 404, description = "One the VTXOs wasn't found", body = error::NotFoundError),
		(status = 500, description = "Internal server error")
	),
	description = "Cooperatively moves the specified VTXOs off the Ark protocol to an \
		on-chain address. Each VTXO is offboarded in full—partial amounts are not \
		supported. The on-chain transaction fee is deducted from the total, and the \
		remaining amount is sent to the destination. If no address is specified, the \
		wallet generates a new on-chain address. To send a specific amount on-chain, \
		use `send-onchain` instead.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn offboard_vtxos(
	State(state): State<Arc<ServerState>>,
	Json(body): Json<bark_json::web::OffboardVtxosRequest>,
) -> HandlerResult<Json<bark_json::cli::OffboardResult>> {
	let wallet = state.require_wallet()?;
	let onchain = state.require_onchain()?;

	if body.vtxos.is_empty() {
		badarg!("No VTXO IDs provided");
	}

	let address = if let Some(addr) = body.address {
		let network = wallet.network().await?;
		bitcoin::Address::from_str(&addr)
			.badarg("invalid destination address")?
			.require_network(network)
			.badarg("address is not valid for configured network")?
	} else {
		onchain.write().await.address().await?
	};

	let mut vtxo_ids = Vec::new();
	for s in body.vtxos {
		let id = ark::VtxoId::from_str(&s).badarg("Invalid VTXO id")?;
		wallet.get_vtxo_by_id(id).await.not_found([id], "VTXO not found")?;
		vtxo_ids.push(id);
	}

	let offboard = wallet.offboard_vtxos(vtxo_ids, address).await?;

	Ok(axum::Json(bark_json::cli::OffboardResult {
		offboard_txid: offboard.txid,
		movement_id: offboard.movement_id,
	}))
}

#[utoipa::path(
	post,
	path = "/offboard/all",
	summary = "Offboard all VTXOs",
	request_body = bark_json::web::OffboardAllRequest,
	responses(
		(status = 200, description = "Returns the offboard transaction id and the movement id",
			body = bark_json::cli::OffboardResult),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Cooperatively moves all spendable VTXOs off the Ark protocol to an \
		on-chain address. Each VTXO is offboarded in full—partial amounts are not \
		supported. The on-chain transaction fee is deducted from the total, and the \
		remaining amount is sent to the destination. If no address is specified, the \
		wallet generates a new on-chain address. To send a specific amount on-chain, \
		use `send-onchain` instead.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn offboard_all(
	State(state): State<Arc<ServerState>>,
	Json(body): Json<bark_json::web::OffboardAllRequest>,
) -> HandlerResult<Json<bark_json::cli::OffboardResult>> {
	let wallet = state.require_wallet()?;
	let onchain = state.require_onchain()?;

	let address = if let Some(addr) = body.address {
		let network = wallet.network().await?;
		bitcoin::Address::from_str(&addr)
			.badarg("invalid destination address")?
			.require_network(network)
			.badarg("address is not valid for configured network")?
	} else {
		onchain.write().await.address().await?
	};

	let offboard = wallet.offboard_all(address).await?;

	Ok(axum::Json(bark_json::cli::OffboardResult {
		offboard_txid: offboard.txid,
		movement_id: offboard.movement_id,
	}))
}

#[utoipa::path(
	post,
	path = "/send-onchain",
	summary = "Send on-chain from Ark balance",
	request_body = bark_json::web::SendOnchainRequest,
	responses(
		(status = 200, description = "Returns the offboard transaction id and the movement id",
			body = bark_json::cli::OffboardResult),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Sends the specified amount to an on-chain address using the wallet's \
		off-chain Ark balance. The on-chain transaction fee is paid on top of the \
		specified amount. Internally creates an out-of-round transaction to consolidate \
		VTXOs into the exact amount needed, then cooperatively sends the on-chain \
		payment via the Ark server. To offboard entire VTXOs without specifying an \
		amount, use `offboard/vtxos` or `offboard/all` instead.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn send_onchain(
	State(state): State<Arc<ServerState>>,
	Json(body): Json<bark_json::web::SendOnchainRequest>,
) -> HandlerResult<Json<bark_json::cli::OffboardResult>> {
	let wallet = state.require_wallet()?;

	let addr = bitcoin::Address::from_str(&body.destination)
		.badarg("invalid destination address")?
		.require_network(wallet.network().await?)
		.badarg("address is not valid for configured network")?;

	let amount = Amount::from_sat(body.amount_sat);

	let offboard = wallet.send_onchain(addr, amount).await?;

	Ok(axum::Json(bark_json::cli::OffboardResult {
		offboard_txid: offboard.txid,
		movement_id: offboard.movement_id,
	}))
}

#[utoipa::path(
	post,
	path = "/sync",
	summary = "Sync wallet",
	responses(
		(status = 200, description = "Wallet was successfully synced"),
	),
	description = "Triggers an immediate sync of the wallet's off-chain state. Updates \
		on-chain fee rates, processes incoming arkoor payments, resolves outgoing and \
		incoming Lightning payments, and progresses pending rounds and boards toward \
		confirmation. The background daemon already runs these operations automatically \
		(e.g., Lightning every second, mailbox and boards every 30 seconds), but calling \
		`sync` forces all of them to run immediately.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn sync(State(state): State<Arc<ServerState>>) -> HandlerResult<()> {
	let wallet = state.require_wallet()?;
	wallet.sync().await;
	Ok(())
}

#[utoipa::path(
	post,
	path = "/sync/mailbox",
	summary = "Sync mailbox only",
	responses(
		(status = 200, description = "Returns the mailbox tip after sync", body = bark_json::web::MailboxSyncResponse),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Triggers an immediate mailbox sync without running any of the other \
		off-chain sync steps. Fetches any pending mailbox messages from the Ark server, \
		processes them (incoming arkoor payments, lightning receive notifications), and \
		returns the new mailbox checkpoint (tip). Useful in `daemon_manual_sync` mode \
		where background mailbox subscription is disabled and the operator needs a \
		granular way to pull incoming events.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn sync_mailbox(
	State(state): State<Arc<ServerState>>,
) -> HandlerResult<Json<bark_json::web::MailboxSyncResponse>> {
	let wallet = state.require_wallet()?;
	wallet.sync_mailbox().await
		.context("failed to sync mailbox")?;
	let checkpoint = wallet.get_mailbox_checkpoint().await
		.context("failed to read mailbox checkpoint")?;
	Ok(axum::Json(bark_json::web::MailboxSyncResponse { checkpoint }))
}

#[utoipa::path(
	post,
	path = "/import-vtxo",
	summary = "Import a VTXO",
	request_body = bark_json::web::ImportVtxoRequest,
	responses(
		(status = 200, description = "VTXO imported successfully", body = Vec<bark_json::primitives::WalletVtxoInfo>),
		(status = 400, description = "Invalid VTXO hex, a VTXO that does not match the chain, or a VTXO whose user pubkey is not derivable from this seed within the gap limit", body = error::BadRequestError),
		(status = 422, description = "The VTXO is neither spendable nor spent, so it cannot be imported yet", body = error::UnprocessableEntityError),
		(status = 500, description = "Internal server error", body = error::InternalServerError)
	),
	description = "Imports the hex-encoded serialized VTXOs in the request body into \
		the wallet; it does not read them from the server mailbox. Validates that each \
		VTXO is anchored on-chain and owned by this wallet. Useful for restoring VTXOs \
		after database loss, or for re-importing ones obtained elsewhere. Ownership is \
		resolved by scanning the seed-derived key space, bounded by `gap_limit` or the \
		wallet's configured gap limit; a key the scan does not reach is a 400. Only \
		VTXOs the server reports as spendable or spent are stored, in that state, so \
		one that has already been spent is recorded as spent rather than rejected. A \
		VTXO still in flight (unclaimed, unregistered, or awaiting a preimage) is \
		rejected with a 422, because it becomes importable once that flow finishes. \
		Pass `skip_status_check` to store them as spendable without asking the server. \
		Expiry is not checked. The VTXOs are imported together, in one key scan and \
		one transaction, so a rejected VTXO leaves none of them stored; pass \
		`allow_partial` to keep the VTXOs that did import, and the response then \
		lists only those. Already-imported VTXOs are skipped, so the operation is \
		idempotent and a failed request can be retried.",
	tag = "wallet"
)]
#[debug_handler]
pub async fn import_vtxo(
	State(state): State<Arc<ServerState>>,
	Json(body): Json<bark_json::web::ImportVtxoRequest>,
) -> HandlerResult<Json<Vec<bark_json::primitives::WalletVtxoInfo>>> {
	let wallet = state.require_wallet()?;

	if body.vtxos.is_empty() {
		badarg!("No VTXOs provided");
	}

	// Caught here too so an out-of-range limit is a bad request rather than the
	// 500 the wallet's own guard would surface.
	if let Some(gap_limit) = body.gap_limit {
		if gap_limit > bark::MAX_VTXO_KEY_GAP_LIMIT {
			badarg!("gap_limit {} is above the maximum of {}",
				gap_limit, bark::MAX_VTXO_KEY_GAP_LIMIT);
		}
	}

	let vtxos = body.vtxos.iter()
		.map(|hex| ark::Vtxo::deserialize_hex(hex))
		.collect::<Result<Vec<_>, _>>()
		.badarg("invalid vtxo hex")?;

	let args = bark::ImportVtxoArgs {
		gap_limit: body.gap_limit,
		skip_status_check: body.skip_status_check,
		allow_partial: body.allow_partial,
	};

	// One key scan covers the batch, so import them together rather than one at
	// a time.
	let ids = match wallet.import_vtxos(&vtxos, args).await {
		Ok(ids) => ids,
		Err(e) => {
			match &e {
				ImportVtxoError::Invalid { .. }
					| ImportVtxoError::KeyNotFound { .. } => badarg!("{}", e),
				// Not a bad request: the vtxo becomes importable once the server
				// finishes the flow it is in.
				ImportVtxoError::InFlight { .. } => unprocessable!("{}", e),
				ImportVtxoError::Transient(..) => {},
			}
			return Err(anyhow::Error::new(e).context("Failed to import VTXOs").into());
		},
	};

	let mut imported = Vec::with_capacity(ids.len());
	for id in ids {
		let wallet_vtxo = wallet.get_vtxo_by_id(id).await
			.context("Failed to get imported VTXO")?;
		imported.push((&wallet_vtxo).into());
	}

	Ok(axum::Json(imported))
}
