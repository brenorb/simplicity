use serde::{Deserialize, Deserializer, Serializer};

/// Deserialize a value, treating `null` or missing fields as `T::default()`.
///
/// Use with `#[serde(default, deserialize_with = "null_as_default")]` to allow
/// both missing and `null` values to deserialize as the default (e.g. empty Vec).
pub fn null_as_default<'de, D, T>(deserializer: D) -> Result<T, D::Error>
where
	D: Deserializer<'de>,
	T: Default + Deserialize<'de>,
{
	Ok(Option::<T>::deserialize(deserializer)?.unwrap_or_default())
}

pub mod duration {
	use super::*;

	use std::time::Duration;

	pub fn serialize<S: Serializer>(duration: &Duration, s: S) -> Result<S::Ok, S::Error> {
		s.collect_str(&humantime::format_duration(*duration))
	}

	pub fn deserialize<'de, D: Deserializer<'de>>(d: D) -> Result<Duration, D::Error> {
		let s = String::deserialize(d)?;
		humantime::parse_duration(&s).map_err(serde::de::Error::custom)
	}
}

pub mod fee_rate_sat_per_kvb {
	use serde::{Deserialize, Deserializer, Serializer};
	use bitcoin::FeeRate;
	use bitcoin_ext::FeeRateExt;

	pub fn serialize<S: Serializer>(v: &FeeRate, s: S) -> Result<S::Ok, S::Error> {
		s.serialize_u64(v.to_sat_per_kvb())
	}

	pub fn deserialize<'de, D: Deserializer<'de>>(d: D) -> Result<FeeRate, D::Error> {
		let sat_kvb = u64::deserialize(d)?;
		Ok(FeeRate::from_sat_per_kvb_ceil(sat_kvb))
	}

	#[allow(unused)]
	pub mod opt {
		use super::*;

		pub fn serialize<S: Serializer>(v: &Option<FeeRate>, s: S) -> Result<S::Ok, S::Error> {
			match v {
				Some(fr) => s.serialize_some(&fr.to_sat_per_kvb()),
				None => s.serialize_none(),
			}
		}

		pub fn deserialize<'de, D: Deserializer<'de>>(d: D) -> Result<Option<FeeRate>, D::Error> {
			let opt = Option::<u64>::deserialize(d)?;
			Ok(opt.map(FeeRate::from_sat_per_kvb_ceil))
		}
	}
}

#[cfg(test)]
mod test {
	use bitcoin::FeeRate;
	use serde::{Deserialize, Serialize};

	#[derive(Debug, PartialEq, Serialize, Deserialize)]
	struct Rates {
		#[serde(with = "super::fee_rate_sat_per_kvb")]
		rate: FeeRate,
		#[serde(with = "super::fee_rate_sat_per_kvb::opt")]
		opt: Option<FeeRate>,
	}

	#[test]
	fn fee_rate_round_trips_at_the_top() {
		for kvb in u64::MAX - 3..=u64::MAX {
			let json = format!(r#"{{"rate":{0},"opt":{0}}}"#, kvb);
			let rates = serde_json::from_str::<Rates>(&json).unwrap();
			let again = serde_json::to_string(&rates).unwrap();
			assert_eq!(serde_json::from_str::<Rates>(&again).unwrap(), rates);
		}
	}
}
