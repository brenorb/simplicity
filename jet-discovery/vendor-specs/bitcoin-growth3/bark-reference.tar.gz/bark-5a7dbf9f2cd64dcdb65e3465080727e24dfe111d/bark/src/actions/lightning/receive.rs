//! State machine for incoming lightning payments.
//!
//! Identity (`invoice`, `payment_hash`, `payment_preimage`) and the
//! parameters fixed at invoice creation (htlc claim cltv delta, anti-dos
//! token) live on the action as top-level fields; the mutable bit is
//! [`Progress`], representing the current phase of the state machine.

use std::str::FromStr;
use std::time::Duration;

use anyhow::Context;
use bitcoin::{Amount, SignedAmount};
use bitcoin::secp256k1::Keypair;
use lightning_invoice::Bolt11Invoice;
use log::{debug, error, info, trace, warn};
use rand::seq::IteratorRandom;

use ark::arkoor::package::ArkoorPackageBuilder;
use ark::arkoor::state::UserGeneratedNonces;
use ark::attestations::{LightningReceiveAttestation, LightningReceiveClaimAttestation};
use ark::fees::validate_and_subtract_fee;
use ark::lightning::{Bolt11InvoiceExt, PaymentHash, Preimage};
use ark::{ProtocolEncoding, Vtxo, VtxoId, VtxoPolicy};
use ark::vtxo::Full;
use bitcoin_ext::{BlockDelta, BlockHeight};
use server_rpc::{protos, ServerConnection};
use server_rpc::protos::prepare_lightning_receive_claim_request::LightningReceiveAntiDos;

use crate::{Config, Wallet};
use crate::actions::{
	abort, or_retry, Advance, AdvanceError, IntoAdvanceResult, IntoAnyhow,
	RetryUnlessRejected, WalletAction, WalletActionCheckpoint, WalletActionId, BASE_RETRY_BACKOFF,
};
use crate::arkoor::{DeliveryOutcome, post_arkoor_to_mailboxes};
use crate::movement::update::MovementUpdate;
use crate::movement::{MovementDestination, MovementId, MovementStatus};
use crate::persist::models::SettledLightningReceive;
use crate::subsystem::{LightningMovement, LightningReceiveMovement, Subsystem};
use crate::vtxo::{validate_vtxo_tree_params, VtxoLockHolder, VtxoState};

const LN_RECV_NAMESPACE: &str = "ln_recv";

/// Leniency delta to allow claim when blocks were mined between htlc
/// receive and claim preparation.
const LIGHTNING_PREPARE_CLAIM_DELTA: BlockDelta = BlockDelta::new(2);

/// How long to sleep between polls while waiting for an inbound payment
const AWAITING_PAYMENT_POLL_INTERVAL: Duration = Duration::from_secs(4);

/// Grace past the bolt11 invoice expiry before an unpaid receive is
/// reaped, to avoid racing a payment that lands right at the boundary.
const INVOICE_EXPIRY_GRACE: Duration = Duration::from_secs(60);

pub(crate) fn ln_recv_action_id(payment_hash: PaymentHash) -> WalletActionId {
	format!("{LN_RECV_NAMESPACE}.{payment_hash}")
}

fn validate_bolt11_payment_hash(
	invoice: &Bolt11Invoice,
	expected_payment_hash: PaymentHash,
) -> anyhow::Result<()> {
	let invoice_payment_hash = PaymentHash::from(invoice);
	ensure!(
		invoice_payment_hash == expected_payment_hash,
		"Ark server returned invoice with payment hash {}, expected {}",
		invoice_payment_hash,
		expected_payment_hash,
	);

	Ok(())
}

/// An incoming lightning payment, persisted as a single checkpoint row
/// stored at invoice creation time.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct LightningReceive {
	// Set at invoice creation, immutable thereafter:
	pub invoice: Bolt11Invoice,
	pub payment_hash: PaymentHash,
	pub payment_preimage: Preimage,
	pub htlc_recv_cltv_delta: BlockDelta,
	pub anti_dos_token: Option<String>,
	#[serde(default)]
	pub claim_destination: Option<ark::Address>,
	/// Index of the wallet key backing the HTLC-recv vtxo and, for local
	/// receives, the claim output.
	pub key_index: u32,

	// Mutable state:
	pub progress: Progress,
	/// How often the claim has failed since the preimage was revealed, held
	/// against [Config::lightning_receive_claim_retries]. Persisted, so the
	/// budget spans restarts. `0` for checkpoints predating this field.
	#[serde(default)]
	pub claim_attempts: u32,
}

impl LightningReceive {
	pub fn id(&self) -> WalletActionId {
		ln_recv_action_id(self.payment_hash)
	}
}

#[cfg_attr(target_arch = "wasm32", async_trait(?Send))]
#[cfg_attr(not(target_arch = "wasm32"), async_trait)]
impl WalletAction for LightningReceive {
	fn id(&self) -> WalletActionId { LightningReceive::id(self) }

	fn from_checkpoint(checkpoint: WalletActionCheckpoint) -> Option<Self> {
		checkpoint.into_lightning_receive()
	}

	async fn advance(self, wallet: &Wallet) -> Result<Advance<Self>, AdvanceError> {
		let new_progress = match &self.progress {
			Progress::AwaitingPayment => {
				match check_incoming_lightning_payment(wallet, &self).await? {
					IncomingStatus::Pending => {
						if invoice_expired(&self.invoice) {
							info!("Removing unpaid expired lightning receive {}", self.payment_hash);
							return Ok(Advance::Done);
						}
						return Ok(Advance::Park {
							state: self,
							wake_after: Some(AWAITING_PAYMENT_POLL_INTERVAL),
							error: None,
						});
					},
					IncomingStatus::Canceled => {
						let err = anyhow!("Lightning receive {} canceled server-side", self.payment_hash);
						return Ok(Advance::Failed(err));
					},
					IncomingStatus::Ready => {
						Progress::HtlcsReady(prepare_lightning_receive_htlcs(wallet, &self).await?)
					},
				}
			},
			Progress::HtlcsReady(htlcs) => {
				// Preimage not revealed yet: if we can no longer finish a
				// unilateral claim in time, abandon rather than commit.
				if is_htlc_claim_window_closed(wallet, htlcs).await.retry()? {
					abandon_lightning_receive(wallet, &self, htlcs).await.retry()?;
					return Ok(Advance::Done);
				}

				// Preparing the claim can fail without consequence.
				let claim = prepare_lightning_receive_claim(wallet, &self, htlcs).await?;
				// In the claim the preimage is revealed so failures are handled carefully.
				match claim_lightning_receive_htlcs(wallet, &self, htlcs, claim).await {
					Ok(None) => return Ok(Advance::Done),
					Ok(Some(delivery)) => Progress::Delivering(delivery),
					Err(e) => {
						// Preimage is out but a post-reveal step failed. Park
						// past the point of no return (PreimageRevealed never
						// abandons) and retry the idempotent claim later,
						// unless the claim retry budget is zero.
						let e = e.into_anyhow();
						warn!("lightning receive {} failed after revealing preimage, \
							retrying claim: {:#}", self.payment_hash, e);
						let budget = wallet.config().lightning_receive_claim_retries;
						return Ok(Advance::Park {
							state: LightningReceive {
								progress: Progress::PreimageRevealed(htlcs.clone()),
								..self
							},
							wake_after: (budget > 0).then_some(BASE_RETRY_BACKOFF),
							error: Some(e),
						});
					},
				}
			},
			Progress::PreimageRevealed(htlcs) => {
				// Retrying claim.
				let claim = prepare_lightning_receive_claim(wallet, &self, htlcs).await?;
				match claim_lightning_receive_htlcs(wallet, &self, htlcs, claim).await? {
					None => return Ok(Advance::Done),
					Some(delivery) => Progress::Delivering(delivery),
				}
			},
			Progress::Delivering(delivery) => {
				deliver_lightning_receive(wallet, &self, delivery).await?;
				return Ok(Advance::Done);
			},
		};

		Ok(Advance::Next(LightningReceive { progress: new_progress, ..self }))
	}

	/// The HTLCs once the preimage has been revealed. Before that the payment
	/// can still be cancelled, so the sats are not the wallet's yet, and claim
	/// outputs being delivered belong to another wallet.
	fn pending_balance_vtxo_ids(&self) -> Vec<VtxoId> {
		match &self.progress {
			Progress::PreimageRevealed(htlcs) => htlcs.vtxo_ids.clone(),
			Progress::AwaitingPayment
				| Progress::HtlcsReady(_)
				| Progress::Delivering(_)
			=> Vec::new(),
		}
	}

	/// The step failed transiently. Retry it, unless the claim window
	/// has closed or the claim retry budget is spent.
	async fn on_retry(self, wallet: &Wallet, error: anyhow::Error) -> Advance<Self> {
		match &self.progress {
			// No money committed; just back off. Expiry reaping happens in
			// the step.
			Progress::AwaitingPayment => Advance::Retry { state: self, error },
			Progress::HtlcsReady(htlcs) => {
				if or_retry!(self, is_htlc_claim_window_closed(wallet, htlcs).await) {
					or_retry!(self, abandon_lightning_receive(wallet, &self, htlcs).await);
					Advance::Failed(error.context("HTLC claim window closed, abandoning"))
				} else {
					Advance::Retry { state: self, error }
				}
			},
			Progress::PreimageRevealed(_) | Progress::Delivering(_) => {
				let budget = u32::from(wallet.config().lightning_receive_claim_retries);
				let state = LightningReceive {
					claim_attempts: self.claim_attempts.saturating_add(1),
					..self
				};
				if state.claim_attempts >= budget {
					let err = error.context("lightning receive claim retry budget exhausted");
					Advance::Park { state, wake_after: None, error: Some(err) }
				} else {
					Advance::Retry { state, error }
				}
			},
		}
	}

	/// The step can't be completed as-is: the server rejected the request
	/// or our own state is inconsistent.
	async fn on_abort(self, wallet: &Wallet, error: anyhow::Error) -> Advance<Self> {
		match &self.progress {
			// Nothing committed server-side: the executor removes the row
			// when the action fails.
			Progress::AwaitingPayment => {
				error!("Could not start lightning receive {}: {:?}", self.id(), error);
				Advance::Failed(error)
			},
			// Preimage not revealed yet: abandon locally (the inbound HTLC
			// times out and the sender is refunded).
			Progress::HtlcsReady(htlcs) => {
				error!("Server rejected lightning receive claim before \
					preimage disclosure, abandoning",
			);
				or_retry!(self, abandon_lightning_receive(wallet, &self, htlcs).await);
				Advance::Failed(error)
			},
			Progress::PreimageRevealed(_) | Progress::Delivering(_) => {
				Advance::Park { state: self, wake_after: None, error: Some(error) }
			},
		}
	}
}

/// The phases of an incoming lightning receive.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum Progress {
	/// Invoice created, waiting for an inbound HTLC. No money yet.
	AwaitingPayment,
	/// Server prepared HTLC-recv vtxos; we hold them locked and the
	/// movement is created. The preimage has NOT been revealed yet, so the
	/// receive is still cancellable.
	HtlcsReady(Htlcs),
	/// The preimage has been revealed via the claim RPC in
	/// exchange of pubkey VTXOs.
	/// Past the point of no return — the receive can no longer be
	/// cancelled. On failure we leave it pending rather than auto-exit;
	/// the caller falls back to an on-chain exit via
	/// `Wallet::attempt_lightning_receive_exit`.
	PreimageRevealed(Htlcs),
	/// The claim outputs are cosigned and held locked; they still need
	/// to be forwarded to the claim destination's mailbox. Only entered
	/// when the receive has a claim destination that isn't our own.
	Delivering(Delivery),
}

/// A handle for the HTLC-recv vtxos the server granted us
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Htlcs {
	/// The VTXO IDs of the HTLC-recv vtxos
	pub vtxo_ids: Vec<VtxoId>,
	/// The ID of the ongoing movement
	pub movement_id: MovementId,
}

/// A handle for the cosigned claim outputs awaiting forwarding to the
/// claim destination
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Delivery {
	/// The VTXOs to be delivered to an external party.
	#[serde(with = "ark::encode::serde::vec")]
	pub vtxos: Vec<Vtxo<Full>>,
	/// The ID of the ongoing movement
	pub movement_id: MovementId,
}

/// Triage of a payment hash on the receive side, mirroring
/// [`LightningSendState`](crate::actions::lightning::pay::LightningSendState):
/// settled (permanent record), in-progress (live checkpoint), or unknown.
#[derive(Debug, Clone)]
pub enum LightningReceiveState {
	InProgress(LightningReceive),
	Settled(SettledLightningReceive),
}

/// Outcome of polling the server for an inbound payment while in
/// [`Progress::AwaitingPayment`].
pub(crate) enum IncomingStatus {
	/// No inbound HTLC yet; keep waiting.
	Pending,
	/// The server is holding HTLCs ready for us to prepare and claim.
	Ready,
	/// The server canceled the hold invoice; nothing to claim.
	Canceled,
}

/// Mint a bolt11 invoice and build a fresh [`LightningReceive`] in
/// [`Progress::AwaitingPayment`]. The executor persists the returned
/// state; the caller is responsible for checkpoint existence checks.
pub(crate) async fn start_lightning_receive(
	wallet: &Wallet,
	amount: Amount,
	description: Option<String>,
	expiry: Option<Duration>,
	token: Option<String>,
	claim_destination: Option<ark::Address>,
) -> anyhow::Result<LightningReceive> {
	if amount == Amount::ZERO {
		bail!("Cannot create invoice for 0 sats (this would create an explicit 0 sat invoice, not an any-amount invoice)");
	}

	if let Some(destination) = claim_destination.as_ref() {
		wallet.validate_arkoor_address(destination).await
			.context("invalid arkoor address")?;
	}

	let (mut srv, ark_info) = wallet.require_server().await?;
	let config = wallet.config();

	let fee = ark_info.fees.lightning_receive.calculate(amount).context("fee overflowed")?;
	validate_and_subtract_fee(amount, fee)?;

	// User needs to enforce the following delta:
	// - vtxo exit delta + htlc expiry delta (time to exit the vtxo before the htlc expires)
	// - vtxo exit margin (time to exit the vtxo before the htlc expires)
	// - htlc recv claim delta (time to claim the htlc before it expires)
	let requested_min_cltv_delta = ark_info.vtxo_exit_delta
		.checked_add(ark_info.htlc_expiry_delta)
		.and_then(|v| v.checked_add(config.vtxo_exit_margin))
		.and_then(|v| v.checked_add(config.htlc_recv_claim_delta))
		.and_then(|v| v.checked_add(LIGHTNING_PREPARE_CLAIM_DELTA))
		.context("HTLC CLTV delta components sum overflows")?;

	if requested_min_cltv_delta > ark_info.max_user_invoice_cltv_delta {
		bail!("HTLC CLTV delta ({}) is greater than Server's max HTLC recv CLTV delta: {}",
			requested_min_cltv_delta,
			ark_info.max_user_invoice_cltv_delta,
		);
	}

	let preimage = Preimage::random();
	let payment_hash = preimage.compute_payment_hash();
	info!("Start bolt11 receive with payment hash: {}", payment_hash);

	let mailbox_kp = wallet.inner.seed.to_mailbox_keypair();
	let mailbox_id = ark::mailbox::MailboxIdentifier::from_pubkey(mailbox_kp.public_key());

	// The HTLC-recv vtxos get locked to this key, and only it can prepare the
	// claim, so nobody else who knows the payment hash can take it over.
	let (claim_keypair, key_index) = wallet.derive_store_next_keypair().await?;

	let req = protos::StartLightningReceiveRequest {
		payment_hash: payment_hash.to_vec(),
		amount_sat: amount.to_sat(),
		min_cltv_delta: requested_min_cltv_delta.into(),
		mailbox_id: Some(mailbox_id.serialize()),
		description,
		expiry_secs: expiry.map(|e| e.as_secs()),
		claim_pubkey: Some(claim_keypair.public_key().serialize().to_vec()),
	};

	let resp = srv.client.start_lightning_receive(req).await?.into_inner();
	info!("Ark Server is ready to receive LN payment to invoice: {}.", resp.bolt11);

	let invoice = Bolt11Invoice::from_str(&resp.bolt11)
		.context("invalid bolt11 invoice returned by Ark server")?;
	validate_bolt11_payment_hash(&invoice, payment_hash)?;
	if let Some(expiry) = expiry {
		// Servers that predate custom expiries ignore the requested one.
		if invoice.expiry_time().as_secs() != expiry.as_secs() {
			bail!("Ark server returned an invoice expiring after {}s instead of the requested {}s, \
				it may not support custom invoice expiries",
				invoice.expiry_time().as_secs(), expiry.as_secs(),
			);
		}
	}


	Ok(LightningReceive {
		invoice,
		payment_hash,
		payment_preimage: preimage,
		htlc_recv_cltv_delta: requested_min_cltv_delta,
		anti_dos_token: token,
		claim_destination,
		key_index,
		progress: Progress::AwaitingPayment,
		claim_attempts: 0,
	})
}

/// Build the anti-dos proof for a claim: an explicit token if the caller
/// supplied one, otherwise an attestation over an owned vtxo.
pub(crate) async fn compute_lightning_receive_anti_dos(
	wallet: &Wallet,
	payment_hash: PaymentHash,
	token: Option<&str>,
) -> anyhow::Result<LightningReceiveAntiDos> {
	Ok(if let Some(token) = token {
		LightningReceiveAntiDos::Token(token.to_string())
	} else {
		let tip = wallet.inner.chain.tip().await?;
		// The proof vtxo isn't spent, so any unexpired one will do; pick at
		// random but keep a 2-block margin: better no proof than one that
		// expires while the claim is in flight.
		let vtxo = wallet.spendable_vtxos().await?.into_iter()
			.filter(|v| v.expiry_height() > tip + BlockDelta::new(2))
			.choose(&mut rand::rng())
			.context("have no spendable vtxo with sufficient expiry margin to prove ownership of")?;
		let vtxo_keypair = wallet.get_vtxo_key(&vtxo).await
			.context("failed to load the key of the anti-dos proof vtxo")?;
		let attestation = LightningReceiveAttestation::new(payment_hash, vtxo.id(), &vtxo_keypair);
		LightningReceiveAntiDos::InputVtxo(protos::InputVtxo {
			vtxo_id: vtxo.id().to_bytes().to_vec(),
			attestation: attestation.serialize(),
		})
	})
}

/// AwaitingPayment poll: ask the server whether an inbound payment has
/// arrived without waiting.
async fn check_incoming_lightning_payment(
	wallet: &Wallet,
	recv: &LightningReceive,
) -> Result<IncomingStatus, AdvanceError> {
	let (mut srv, _) = wallet.require_server().await.retry()?;
	let sub = srv.client.check_lightning_receive(protos::CheckLightningReceiveRequest {
		hash: recv.payment_hash.to_byte_array().to_vec(),
		wait: false,
	}).await.retry_unless_rejected()?.into_inner();

	// An unknown status is most likely a server we don't fully speak with yet;
	// keep polling rather than drop a receive that may still get paid.
	let status = protos::LightningReceiveStatus::try_from(sub.status)
		.with_context(|| format!("unknown payment status: {}", sub.status)).retry()?;
	debug!("Received status {:?} for {}", status, recv.payment_hash);

	Ok(match status {
		protos::LightningReceiveStatus::Accepted |
		protos::LightningReceiveStatus::HtlcsReady => IncomingStatus::Ready,
		protos::LightningReceiveStatus::Created => IncomingStatus::Pending,
		protos::LightningReceiveStatus::Canceled => IncomingStatus::Canceled,
		// We never claimed, yet the server has the preimage. Polling
		// won't change that, so fail the receive and surface it.
		protos::LightningReceiveStatus::Settled => abort!("payment already settled"),
	})
}

/// The number of blocks we need, counted from now, to claim an HTLC-recv
/// vtxo unilaterally once the server refuses to cosign.
fn htlc_recv_exit_blocks_needed(
	exit_delta: BlockDelta,
	htlc_expiry_delta: BlockDelta,
	config: &Config,
) -> anyhow::Result<BlockDelta> {
	exit_delta
		.checked_add(htlc_expiry_delta)
		.and_then(|v| v.checked_add(config.vtxo_exit_margin))
		.and_then(|v| v.checked_add(config.htlc_recv_claim_delta))
		.context("HTLC recv exit delta components sum overflows")
}

/// The HTLC-recv expiry to request when claiming. Leaves out
/// [LIGHTNING_PREPARE_CLAIM_DELTA] so the claim tolerates our tip being
/// that many blocks ahead of the sender's.
fn htlc_recv_expiry(current_height: BlockHeight, cltv_delta: BlockDelta) -> BlockHeight {
	current_height + cltv_delta.saturating_sub(LIGHTNING_PREPARE_CLAIM_DELTA)
}

/// The number of blocks of life we need, counted from now, on the tree
/// backing an HTLC-recv vtxo.
///
/// Much shorter than [htlc_recv_exit_blocks_needed]: the expiry height binds
/// the tree nodes above the leaf, not the HTLC leaf script itself (see
/// [VtxoPolicy::taproot]), so the tree only has to outlive confirmation of
/// our exit chain, which [Config::vtxo_exit_margin] bounds.
///
/// One margin covers the grant however it plays out. If the server refuses to
/// cosign the claim, we exit the HTLC-recv vtxo. If it does cosign, the claim
/// output inherits the tree's expiry and exits over the same branch. Only one
/// of the two ever happens, and [is_htlc_claim_window_closed] re-checks the
/// margin against the tip before we reveal the preimage.
fn htlc_recv_tree_blocks_needed(config: &Config) -> BlockDelta {
	config.vtxo_exit_margin
}

/// AwaitingPayment -> HtlcsReady. Asks the server to grant HTLC-recv
/// vtxos for the inbound payment, validates them, creates the receive
/// movement and stores the vtxos locked.
///
/// A grant we are not willing to claim against aborts: the server hands
/// back the same grant on every later request for this payment hash, so
/// the receive fails while the preimage is still ours.
async fn prepare_lightning_receive_htlcs(
	wallet: &Wallet,
	recv: &LightningReceive,
) -> Result<Htlcs, AdvanceError> {
	let (mut srv, ark_info) = wallet.require_server().await.retry()?;
	let config = wallet.config();
	let current_height = wallet.inner.chain.tip().await.retry()?;
	let payment_hash = recv.payment_hash;

	let lightning_receive_anti_dos = match compute_lightning_receive_anti_dos(
		wallet, payment_hash, recv.anti_dos_token.as_deref(),
	).await {
		Ok(anti_dos) => Some(anti_dos),
		Err(e) => {
			info!("Could not compute anti-dos: {e:#}. Trying without");
			None
		},
	};

	let htlc_recv_expiry = htlc_recv_expiry(current_height, recv.htlc_recv_cltv_delta);
	let keypair = wallet.peek_keypair(recv.key_index).await.retry()?;
	let req = protos::PrepareLightningReceiveClaimRequest {
		payment_hash: payment_hash.to_vec(),
		user_pubkey: keypair.public_key().serialize().to_vec(),
		htlc_recv_expiry: htlc_recv_expiry.into(),
		lightning_receive_anti_dos,
		claim_attestation: Some(
			LightningReceiveClaimAttestation::new(payment_hash, htlc_recv_expiry, &keypair).serialize(),
		),
	};
	let res = srv.client.prepare_lightning_receive_claim(req).await
		.retry_unless_rejected()?.into_inner();

	// The server hands back this very same grant on every later request for
	// this payment hash, so a grant we can't accept aborts rather than
	// retries: `abort` fails the receive while the preimage is still ours.
	let vtxos = res.htlc_vtxos.into_iter()
		.map(|b| Vtxo::deserialize(&b))
		.collect::<Result<Vec<_>, _>>()
		.context("invalid htlc vtxos from server").abort()?;

	// Sanity-check the vtxos.
	let mut htlc_amount = Amount::ZERO;
	for vtxo in &vtxos {
		trace!("Received HTLC VTXO {} from server: {}", vtxo.id(), vtxo.serialize_hex());
		//TODO(stevenroose) distinguish chain-source from invalid input
		wallet.validate_vtxo(vtxo).await
			.context("received invalid HTLC VTXO from server").retry()?;
		htlc_amount += vtxo.amount();

		if let VtxoPolicy::ServerHtlcRecv(p) = vtxo.policy() {
			if p.payment_hash != payment_hash {
				abort!("invalid payment hash on HTLC VTXOs received from server: {}",
					p.payment_hash,
				);
			}
			if p.user_pubkey != keypair.public_key() {
				abort!("invalid pubkey on HTLC VTXOs received from server: {}", p.user_pubkey);
			}
			// NB: p.htlc_expiry isn't compared against the freshly computed
			// htlc_recv_expiry: the server hands back the first attempt's
			// grant, so any block mined since would fail on every retry. The
			// claim deadline check below covers the grant's headroom.

			// Ensure that the server didn't inflate the deltas for the client's
			// unilateral exit clauses. Don't retry on any failure here: the
			// server hands back these very same vtxos on every later request
			// for this payment hash.
			let claim_by = htlc_recv_exit_blocks_needed(
				vtxo.exit_delta(), p.htlc_expiry_delta, config,
			).and_then(|blocks_needed| {
				current_height.checked_add(blocks_needed)
					.context("HTLC VTXO claim deadline overflows")
			}).abort()?;
			if claim_by > p.htlc_expiry {
				abort!(
					"HTLC VTXO timelocks leave no time to claim it unilaterally: we need \
					until height {} (exit delta {}, htlc expiry delta {}), but the server \
					can claim it from height {}",
					claim_by, vtxo.exit_delta(), p.htlc_expiry_delta, p.htlc_expiry,
				);
			}

			// The server also chose the leaf's tree-level parameters, so validate
			// them against the advertised ones like round outputs.
			let blocks_needed = htlc_recv_tree_blocks_needed(config);
			let tree_expiry_by = current_height.checked_add(blocks_needed)
				.context("HTLC VTXO tree expiry deadline overflows").abort()?;
			validate_vtxo_tree_params(
				vtxo.server_pubkey(), vtxo.exit_delta(), vtxo.expiry_height(),
				ark_info.server_pubkey, ark_info.vtxo_exit_delta, tree_expiry_by,
			).abort()?;
		} else {
			abort!("invalid HTLC VTXO policy: {:?}", vtxo.policy());
		}
	}

	// We can't entirely trust the server-reported payment amount, so if there is a
	// discrepancy, fall back to checking the invoice amount.
	let invoice_amount = recv.invoice.get_payment_amount(None)
		.context("ln receive invoice should have amount").abort()?;
	let server_received_amount = res.receive.map(|r| Amount::from_sat(r.amount_sat));
	let fee = {
		let fee = server_received_amount
			.and_then(|a| ark_info.fees.lightning_receive.calculate(a));
		match (server_received_amount, fee) {
			(Some(amount), Some(fee)) if htlc_amount + fee == amount => fee,
			// Validated when the invoice was created, but the fee schedule
			// comes from the server and can change between drives.
			_ => ark_info.fees.lightning_receive.calculate(invoice_amount)
				.context("lightning receive fee overflows").abort()?,
		}
	};
	let received = htlc_amount + fee;
	if received < invoice_amount {
		abort!("Server didn't return enough VTXOs to cover invoice amount");
	}

	// The grant is accepted; the bookkeeping below is local and retried.
	let movement_id = wallet.inner.movements.get_or_create_movement_with_action(
		Subsystem::LIGHTNING_RECEIVE,
		LightningReceiveMovement::Receive.to_string(),
		&recv.id(),
		MovementUpdate::new()
			.intended_balance(invoice_amount.to_signed()
				.context("invoice amount out of range").abort()?)
			.effective_balance(htlc_amount.to_signed()
				.context("htlc amount out of range").abort()?)
			.fee(fee)
			.metadata(LightningMovement::metadata(
				payment_hash, &vtxos, Some(recv.payment_preimage),
			))
			.received_on([MovementDestination::new(recv.invoice.clone().into(), received)]),
	).await.context("failed to create lightning receive movement").retry()?;
	wallet.store_locked_vtxos(
		&vtxos,
		Some(VtxoLockHolder::Action { id: recv.id() }),
	).await.retry()?;

	// Sort for a deterministic checkpoint (the server may return them in any order).
	let mut vtxo_ids = vtxos.iter().map(|v| v.id()).collect::<Vec<_>>();
	vtxo_ids.sort();

	Ok(Htlcs { vtxo_ids, movement_id })
}

/// A claim for the granted HTLC vtxos, built but not sent. The preimage
/// has not gone out yet, so the receive can still be abandoned.
struct PreparedClaim {
	srv: ServerConnection,
	builder: ArkoorPackageBuilder<UserGeneratedNonces>,
	keypairs: Vec<Keypair>,
}

/// Build the claim for the granted HTLC vtxos without revealing the
/// preimage. A failure here leaves the receive abandonable.
async fn prepare_lightning_receive_claim(
	wallet: &Wallet,
	recv: &LightningReceive,
	htlcs: &Htlcs,
) -> Result<PreparedClaim, AdvanceError> {
	let (srv, _) = wallet.require_server().await.retry()?;

	// Order inputs by vtxoid before generating nonces, then hydrate to
	// full so the arkoor builder has the genesis chain.
	let mut input_ids = htlcs.vtxo_ids.clone();
	input_ids.sort();
	let inputs = wallet.inner.db.get_full_vtxos(&input_ids).await
		.context("failed to hydrate htlc input vtxos").retry()?;

	let mut keypairs = Vec::with_capacity(inputs.len());
	for v in &inputs {
		keypairs.push(wallet.get_vtxo_key(v).await.retry()?);
	}

	let receive_policy = if let Some(destination) = recv.claim_destination.as_ref() {
		destination.policy().clone()
	} else {
		let claim_key = wallet.peek_keypair(recv.key_index).await.retry()?.public_key();
		VtxoPolicy::new_pubkey(claim_key)
	};
	trace!("ln claim arkoor params: inputs: {:?}; policy: {:?}", input_ids, receive_policy);
	// The claim is built from our own stored vtxos, so failing to build it
	// is deterministic: abort, which abandons the receive while the preimage
	// is still ours.
	let builder = ArkoorPackageBuilder::new_claim_all_with_checkpoints(
		inputs, receive_policy,
	).context("creating claim arkoor builder failed").abort()?
		.generate_user_nonces(&keypairs)
		.context("arkoor nonce generation for claim failed").abort()?;

	Ok(PreparedClaim { srv, builder, keypairs })
}

/// Claiming -> done, or -> Delivering when the receive has a claim
/// destination that isn't our own. Reveals the preimage to the server in
/// exchange for a cosigned claim. Local receives finalise the movement
/// and write the permanent settled record here; external destinations
/// hold the outputs locked and hand off to [`deliver_lightning_receive`].
///
/// The server's `claim_lightning_receive` is idempotent on payment hash,
/// so this is safe to re-drive after a crash: a fresh cosign is returned
/// for the new nonces. Whatever this returns, the caller must assume the
/// preimage is out.
async fn claim_lightning_receive_htlcs(
	wallet: &Wallet,
	recv: &LightningReceive,
	htlcs: &Htlcs,
	claim: PreparedClaim,
) -> Result<Option<Delivery>, AdvanceError> {
	let PreparedClaim { mut srv, builder, keypairs } = claim;

	info!("Claiming arkoor against payment preimage for {}", recv.payment_hash);
	let package_cosign_request = protos::ArkoorPackageCosignRequest::from(builder.cosign_request());
	let resp = srv.client.claim_lightning_receive(protos::ClaimLightningReceiveRequest {
		payment_hash: recv.payment_hash.to_byte_array().to_vec(),
		payment_preimage: recv.payment_preimage.to_vec(),
		cosign_request: Some(package_cosign_request),
	}).await.retry_unless_rejected()?.into_inner();

	// The preimage is out, so from here on only retry: the server's
	// claim_lightning_receive is idempotent and hands out fresh cosign
	// signatures for a re-driven claim.

	let cosign_resp = resp.try_into().context("invalid cosign response").retry()?;

	let mut outputs = builder.user_cosign(&keypairs, cosign_resp)
		.context("claim arkoor cosign failed with user response").retry()?
		.build_signed_vtxos();

	// Register the claim outputs so they are spendable for any later flow.
	wallet.register_vtxo_transactions_with_server(&outputs).await.retry()?;

	let mut effective_balance = Amount::ZERO;
	for vtxo in &outputs {
		// NB: bailing here results in vtxos not being registered despite the
		// preimage being revealed; see above on why a retry is fine.
		trace!("Validating Lightning receive claim VTXO {}: {}", vtxo.id(), vtxo.serialize_hex());
		wallet.validate_vtxo(vtxo).await
			.context("invalid arkoor from lightning receive").retry()?;
		effective_balance += vtxo.amount();
	}

	info!("Got arkoors from lightning: {}",
		outputs.iter().map(|v| v.id().to_string()).collect::<Vec<_>>().join(", "));

	// A destination owned by this wallet needs no mailbox delivery: the
	// outputs are already keyed to one of our pubkeys.
	let external_destination = match recv.claim_destination.as_ref() {
		Some(destination) => wallet.pubkey_keypair(&destination.policy().user_pubkey())
			.await.retry()?.is_none(),
		None => false,
	};

	if external_destination {
		wallet.mark_vtxos_as_spent(&htlcs.vtxo_ids).await.retry()?;
		outputs.sort_unstable();
		return Ok(Some(Delivery {
			vtxos: outputs,
			movement_id: htlcs.movement_id,
		}));
	}

	if let Err(e) = wallet.post_recovery_vtxo_ids(outputs.iter().map(|v| v.id())).await {
		error!("Failed to post recovery vtxo IDs to server: {:#}", e);
	}
	// Spend the inputs first: these two writes can't be atomic, and counting
	// the receive in neither balance for a moment beats counting it in both.
	wallet.mark_vtxos_as_spent(&htlcs.vtxo_ids).await.retry()?;
	wallet.store_vtxos(&outputs, &VtxoState::Spendable).await.retry()?;

	// Write the permanent settled record before finishing the movement:
	// finishing dispatches the `MovementUpdated` notification, and a
	// consumer reacting to it must already find the receive settled.
	let amount = recv.invoice.get_payment_amount(None).unwrap_or(effective_balance);
	wallet.inner.db.record_settled_lightning_receive(
		recv.payment_hash, recv.payment_preimage, &recv.invoice, amount,
	).await.retry()?;

	wallet.inner.movements.finish_movement_with_update(
		htlcs.movement_id,
		MovementStatus::Successful,
		MovementUpdate::new()
			.effective_balance(effective_balance.to_signed()
				.context("effective balance out of range").abort()?)
			.produced_vtxos(&outputs),
	).await.context("failed to finish lightning receive movement").retry()?;

	Ok(None)
}

/// Delivering -> done. Forwards the locked claim outputs to the claim
/// destination's mailbox, then writes the permanent settled record and
/// finalises the movement. Re-driving after a crash at most posts the
/// same vtxos to the mailbox again.
async fn deliver_lightning_receive(
	wallet: &Wallet,
	recv: &LightningReceive,
	delivery: &Delivery,
) -> Result<(), AdvanceError> {
	let destination = recv.claim_destination.as_ref()
		.context("delivering receive has no claim destination")
		.abort()?;
	deliver_vtxos_to_address(wallet, destination, &delivery.vtxos).await
		.context("failed to deliver lightning receive claim output to destination mailbox")
		.retry()?;

	let delivered = delivery.vtxos.iter().map(|v| v.amount()).sum();
	// Settled record first, then the movement: see claim_lightning_receive_htlcs.
	let amount = recv.invoice.get_payment_amount(None).unwrap_or(delivered);
	wallet.inner.db.record_settled_lightning_receive(
		recv.payment_hash, recv.payment_preimage, &recv.invoice, amount,
	).await.retry()?;

	wallet.inner.movements.finish_movement_with_update(
		delivery.movement_id,
		MovementStatus::Successful,
		MovementUpdate::new()
			.effective_balance(SignedAmount::ZERO)
			.sent_to([MovementDestination::ark(destination.clone(), delivered)]),
	).await.context("failed to finish lightning receive movement").retry()?;

	Ok(())
}

async fn deliver_vtxos_to_address(
	wallet: &Wallet,
	destination: &ark::Address,
	vtxos: &[Vtxo<ark::vtxo::Full>],
) -> anyhow::Result<()> {
	let (mut srv, _) = wallet.require_server().await?;

	match post_arkoor_to_mailboxes(&mut srv, destination.delivery(), vtxos).await {
		DeliveryOutcome::AnySucceeded => Ok(()),
		DeliveryOutcome::AllFailed { summary } => bail!(summary),
	}
}

/// HtlcsReady abandon: the preimage was never revealed, so we simply drop
/// the HTLC vtxos and finish the movement as canceled. The inbound HTLC
/// times out server-side and the sender is refunded.
pub(crate) async fn abandon_lightning_receive(
	wallet: &Wallet,
	recv: &LightningReceive,
	htlcs: &Htlcs,
) -> anyhow::Result<()> {
	warn!("Abandoning lightning receive {} before preimage disclosure", recv.payment_hash);
	wallet.mark_vtxos_as_spent(&htlcs.vtxo_ids).await?;
	wallet.inner.movements.finish_movement_with_update(
		htlcs.movement_id,
		MovementStatus::Canceled,
		MovementUpdate::new().effective_balance(SignedAmount::ZERO),
	).await?;
	Ok(())
}

/// Returns whether the claim window on the granted HTLC-recv vtxos has
/// closed, in which case the caller must abandon rather than reveal the
/// preimage.
///
/// Every granted vtxo is held to the two budgets
/// [prepare_lightning_receive_htlcs] accepted the grant against: the claim
/// must finish before the server can race us at the HTLC expiry, and our
/// exit chain must confirm before the server can sweep the tree at the VTXO
/// expiry. Both deadlines live on the stored vtxos, not the checkpoint.
pub(crate) async fn is_htlc_claim_window_closed(
	wallet: &Wallet,
	htlcs: &Htlcs,
) -> anyhow::Result<bool> {
	ensure!(!htlcs.vtxo_ids.is_empty(), "no HTLC vtxos on receive");

	let config = wallet.config();
	let tip = wallet.inner.chain.tip().await?;
	// Bails if any id is missing, so every granted vtxo is checked.
	let vtxos = wallet.inner.db.get_full_vtxos(&htlcs.vtxo_ids).await
		.context("failed to hydrate htlc vtxos")?;
	for vtxo in &vtxos {
		let p = match vtxo.policy() {
			VtxoPolicy::ServerHtlcRecv(p) => p,
			other => bail!("HTLC receive vtxo has unexpected policy: {:?}", other),
		};

		let claim_by = htlc_recv_exit_blocks_needed(
			vtxo.exit_delta(), p.htlc_expiry_delta, config,
		).map(|blocks| tip + blocks)?;
		if claim_by > p.htlc_expiry {
			debug!("HTLC vtxo {} needs until height {} to claim, but the server \
				can claim it from height {}", vtxo.id(), claim_by, p.htlc_expiry);
			return Ok(true);
		}

		let tree_expiry_by = tip + htlc_recv_tree_blocks_needed(config);
		if tree_expiry_by > vtxo.expiry_height() {
			debug!("HTLC vtxo {} needs its backing tree until height {}, but it \
				expires at height {}", vtxo.id(), tree_expiry_by, vtxo.expiry_height());
			return Ok(true);
		}
	}

	Ok(false)
}

/// Whether an unpaid invoice has passed its bolt11 expiry plus a grace
/// margin and can be reaped.
pub(crate) fn invoice_expired(invoice: &Bolt11Invoice) -> bool {
	let now_secs = chrono::Utc::now().timestamp();
	if now_secs < 0 {
		return false;
	}
	let cutoff = Duration::from_secs(now_secs as u64).saturating_sub(INVOICE_EXPIRY_GRACE);
	invoice.would_expire(cutoff)
}

#[cfg(test)]
mod tests {
	use super::*;

	const TEST_INVOICE_STR: &str = "lntbs100u1p5j0x82sp5d0rwfh7tgrrlwsegy9rx3tzpt36cqwjqza5x4wvcjxjzscfaf6jspp5d8q7354dg3p8h0kywhqq5dq984r8f5en98hf9ln85ug0w8fx6hhsdqqcqzpc9qyysgqyk54v7tpzprxll7e0jyvtxcpgwttzk84wqsfjsqvcdtq47zt2wssxsmtjhz8dka62mdnf9jafhu3l4cpyfnsx449v4wstrwzzql2w5qqs8uh7p";

	fn test_bolt11() -> Bolt11Invoice {
		Bolt11Invoice::from_str(TEST_INVOICE_STR).expect("valid test invoice")
	}

	#[test]
	fn validate_bolt11_payment_hash_accepts_matching_hash() {
		let invoice = test_bolt11();
		let payment_hash = PaymentHash::from(&invoice);

		validate_bolt11_payment_hash(&invoice, payment_hash).unwrap();
	}

	#[test]
	fn validate_bolt11_payment_hash_rejects_mismatched_hash() {
		let invoice = test_bolt11();
		let mismatched_payment_hash = PaymentHash::from_slice(&[0xabu8; 32]).unwrap();

		let err = validate_bolt11_payment_hash(&invoice, mismatched_payment_hash)
			.expect_err("mismatched payment hash should fail");

		assert!(
			err.to_string().contains("returned invoice with payment hash"),
			"{err:?}",
		);
	}

	/// The blocks we ask the server to put between the tip and `htlc_expiry`
	/// when creating the invoice, see [start_lightning_receive].
	fn requested_cltv_delta(
		exit_delta: BlockDelta,
		htlc_expiry_delta: BlockDelta,
		config: &Config,
	) -> BlockDelta {
		exit_delta + htlc_expiry_delta + config.vtxo_exit_margin
			+ config.htlc_recv_claim_delta + LIGHTNING_PREPARE_CLAIM_DELTA
	}

	#[test]
	fn htlc_recv_exit_blocks_needed_fits_the_requested_cltv_delta() {
		let config = Config::network_default(bitcoin::Network::Bitcoin);

		// A server granting the deltas it advertised leaves us
		// LIGHTNING_PREPARE_CLAIM_DELTA to spare.
		for (exit_delta, htlc_expiry_delta) in [(144, 6), (144, 40), (100, 0)] {
			let (exit_delta, htlc_expiry_delta) =
				(BlockDelta::new(exit_delta), BlockDelta::new(htlc_expiry_delta));
			let needed = htlc_recv_exit_blocks_needed(
				exit_delta, htlc_expiry_delta, &config,
			).unwrap();
			let requested = requested_cltv_delta(exit_delta, htlc_expiry_delta, &config);

			assert_eq!(requested.saturating_sub(needed), LIGHTNING_PREPARE_CLAIM_DELTA);
		}
	}

	#[test]
	fn htlc_recv_expiry_tolerates_blocks_mined_since_the_sender_paid() {
		let config = Config::network_default(bitcoin::Network::Bitcoin);
		let (exit_delta, htlc_expiry_delta) = (BlockDelta::new(144), BlockDelta::new(6));
		let cltv_delta = requested_cltv_delta(exit_delta, htlc_expiry_delta, &config);
		let needed = htlc_recv_exit_blocks_needed(exit_delta, htlc_expiry_delta, &config).unwrap();

		// The invoice delta is ours plus the server's `htlc_expiry_delta`.
		let sender_tip = BlockHeight::new(1000);
		let incoming_expiry = sender_tip + cltv_delta + htlc_expiry_delta;

		for drift in 0..=LIGHTNING_PREPARE_CLAIM_DELTA.to_u16() {
			let tip = sender_tip + BlockDelta::new(drift);
			let expiry = htlc_recv_expiry(tip, cltv_delta);
			assert!(expiry + htlc_expiry_delta <= incoming_expiry,
				"server would refuse the claim {drift} blocks after the sender paid",
			);
			assert!(tip + needed <= expiry,
				"vtxo leaves no time to exit {drift} blocks after the sender paid",
			);
		}

		let tip = sender_tip + LIGHTNING_PREPARE_CLAIM_DELTA + BlockDelta::new(1);
		let expiry = htlc_recv_expiry(tip, cltv_delta);
		assert!(expiry + htlc_expiry_delta > incoming_expiry);
	}

	#[test]
	fn htlc_recv_exit_blocks_needed_exceeds_cltv_delta_when_server_inflates_a_delta() {
		let config = Config::network_default(bitcoin::Network::Bitcoin);
		let requested = requested_cltv_delta(BlockDelta::new(144), BlockDelta::new(6), &config);

		// Inflating either delta past the leniency delta eats the whole window.
		let inflated_expiry_delta =
			htlc_recv_exit_blocks_needed(BlockDelta::new(144), BlockDelta::new(9), &config).unwrap();
		assert!(inflated_expiry_delta > requested);

		let inflated_exit_delta =
			htlc_recv_exit_blocks_needed(BlockDelta::new(147), BlockDelta::new(6), &config).unwrap();
		assert!(inflated_exit_delta > requested);
	}

	#[test]
	fn htlc_recv_exit_blocks_needed_rejects_overflowing_deltas() {
		let config = Config::network_default(bitcoin::Network::Bitcoin);

		htlc_recv_exit_blocks_needed(BlockDelta::MAX, BlockDelta::MAX, &config)
			.expect_err("summing the deltas should overflow");
	}

	/// The tree only has to outlive one exit margin, far less than the whole
	/// claim needs, so a tree bark can still exit from isn't refused.
	#[test]
	fn htlc_recv_tree_blocks_needed_stays_under_a_full_claim() {
		let mut config = Config::network_default(bitcoin::Network::Bitcoin);
		config.vtxo_exit_margin = BlockDelta::new(12);

		assert_eq!(htlc_recv_tree_blocks_needed(&config), BlockDelta::new(12));

		let needed = htlc_recv_exit_blocks_needed(
			BlockDelta::new(144), BlockDelta::new(40), &config,
		).unwrap();
		assert!(htlc_recv_tree_blocks_needed(&config) < needed);
	}
}
