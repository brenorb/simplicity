//! Arkoor send wallet action.
//!
//! Identity (`id`, `destination`, `amount`) and immutable parameters live
//! on [`ArkoorSend`] as top-level fields; the mutable bit is the [`Progress`] enum.

use std::time::Duration;

use anyhow::Context;
use bitcoin::Amount;
use bitcoin::hex::DisplayHex;
use log::{error, info};

use ark::arkoor::ArkoorDestination;
use ark::vtxo::{Full, VtxoId, Vtxo};

use crate::Wallet;
use crate::actions::{
	Advance, AdvanceError, IntoAdvanceResult, RetryUnlessRejected, WalletAction,
	WalletActionCheckpoint, WalletActionId,
};
use crate::arkoor::{post_arkoor_to_mailboxes, split_change_amount, DeliveryOutcome};
use crate::movement::{MovementDestination, MovementId, MovementStatus};
use crate::movement::update::MovementUpdate;
use crate::subsystem::{ArkoorMovement, Subsystem};
use crate::vtxo::VtxoLockHolder;

/// How long to wait before re-attempting delivery in the
/// [`Progress::Delivery`] park path.
const DELIVERY_RETRY_BACKOFF: Duration = Duration::from_secs(60);

/// An in-flight arkoor payment to an [`ark::Address`], persisted
/// as a single checkpoint row and driven across crashes by the
/// executor.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ArkoorSend {
	// Immutable State:
	pub id: WalletActionId,
	pub destination: ark::Address,
	#[serde(with = "bitcoin::amount::serde::as_sat")]
	pub amount: Amount,
	pub input_vtxo_ids: Vec<VtxoId>,
	pub change_key_index: u32,
	/// Change piece amounts fixed at start. `None` when persisted by a
	/// pre-split bark, meaning one whole change output.
	#[serde(default, with = "crate::utils::serde::opt_amount_vec_sat")]
	pub change_pieces: Option<Vec<Amount>>,

	// Mutable state:
	pub progress: Progress,
}

impl ArkoorSend {
	pub fn id(&self) -> WalletActionId {
		self.id.clone()
	}
}

/// The four phases of an outgoing arkoor send.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum Progress {
	/// Inputs are selected and the change keypair is reserved. This step
	/// locks the inputs before it asks the server to co-sign.
	Cosigning,
	/// Cosign succeeded and the movement is recorded; pending registration of
	/// the signed vtxo transactions with the server.
	Registration {
		movement_id: MovementId,
		#[serde(with = "ark::encode::serde::vec")]
		signed_destination_vtxos: Vec<Vtxo<Full>>,
		#[serde(with = "ark::encode::serde::vec")]
		signed_change_vtxos: Vec<Vtxo<Full>>,
	},
	/// Registration succeeded; pending delivery of the signed vtxos to the
	/// recipient via the destination's mailbox mechanisms.
	Delivery {
		movement_id: MovementId,
		#[serde(with = "ark::encode::serde::vec")]
		signed_destination_vtxos: Vec<Vtxo<Full>>,
		#[serde(with = "ark::encode::serde::vec")]
		signed_change_vtxos: Vec<Vtxo<Full>>,
		/// Most recent reason a delivery pass parked. `None` until the first
		/// pass in which no mailbox accepted the post.
		last_park_error: Option<String>,
	},
	/// At least one delivery succeeded or the action was salvaged
	/// after retry exhaustion.
	Finalizing {
		movement_id: MovementId,
		#[serde(with = "ark::encode::serde::vec")]
		signed_change_vtxos: Vec<Vtxo<Full>>,
		/// `true` if at least one delivery mechanism acked the message or
		/// the address requested no delivery at all, `false` if we are
		/// finalizing post-retry-exhaustion to salvage the change.
		delivery_succeeded: bool,
	},
}

#[cfg_attr(target_arch = "wasm32", async_trait(?Send))]
#[cfg_attr(not(target_arch = "wasm32"), async_trait)]
impl WalletAction for ArkoorSend {
	fn id(&self) -> WalletActionId { ArkoorSend::id(self) }

	fn from_checkpoint(checkpoint: WalletActionCheckpoint) -> Option<Self> {
		checkpoint.into_arkoor_send()
	}

	async fn advance(self, wallet: &Wallet) -> Result<Advance<Self>, AdvanceError> {
		let new_progress = match self.progress {
			Progress::Cosigning => run_cosign(wallet, &self).await?,
			Progress::Registration {
				movement_id, signed_destination_vtxos, signed_change_vtxos,
			} => {
				let vtxos = signed_destination_vtxos.iter().chain(&signed_change_vtxos);
				wallet.register_vtxo_transactions_with_server(vtxos).await
					.retry_unless_rejected()?;
				Progress::Delivery {
					movement_id,
					signed_destination_vtxos,
					signed_change_vtxos,
					last_park_error: None,
				}
			},
			Progress::Delivery {
				movement_id, signed_destination_vtxos, signed_change_vtxos,
				last_park_error: _,
			} => {
				// The receiver explicitly wants no delivery. We should honour it
				if self.destination.delivery().is_empty() {
					return Ok(Advance::Next(ArkoorSend {
						progress: Progress::Finalizing {
							movement_id,
							signed_change_vtxos,
							delivery_succeeded: true,
						},
						..self
					}));
				}

				let (mut srv, _) = wallet.require_server().await.retry()?;
				match post_arkoor_to_mailboxes(
					&mut srv, self.destination.delivery(), &signed_destination_vtxos,
				).await {
					DeliveryOutcome::AnySucceeded => Progress::Finalizing {
						movement_id,
						signed_change_vtxos,
						delivery_succeeded: true,
					},
					DeliveryOutcome::AllFailed { summary } => {
						return Ok(Advance::Park {
							state: ArkoorSend {
								progress: Progress::Delivery {
									movement_id, signed_destination_vtxos,
									signed_change_vtxos,
									last_park_error: Some(summary.clone()),
								},
								..self
							},
							wake_after: Some(DELIVERY_RETRY_BACKOFF),
							error: Some(anyhow!(summary)),
						});
					},
				}
			},
			Progress::Finalizing { movement_id, signed_change_vtxos, delivery_succeeded } => {
				finalize_arkoor_send(
					wallet, &self.input_vtxo_ids, movement_id,
					&signed_change_vtxos, delivery_succeeded,
				).await?;
				return Ok(Advance::Done);
			},
		};

		Ok(Advance::Next(ArkoorSend { progress: new_progress, ..self }))
	}

	/// The inputs. They stay locked, and the change is not stored, until the
	/// send finalizes, which spends the inputs and releases the change.
	fn pending_balance_vtxo_ids(&self) -> Vec<VtxoId> {
		self.input_vtxo_ids.clone()
	}

	/// The step can't be completed as-is: the server rejected the request
	/// or our own state is inconsistent.
	async fn on_abort(self, _wallet: &Wallet, error: anyhow::Error) -> Advance<Self> {
		match self.progress {
			// Nothing happened server-side, so the inputs go back to spendable
			// when the executor tears the action down.
			Progress::Cosigning => {
				error!("arkoor send {} rejected during cosign: {:?}", self.id, error);
				Advance::Failed(error)
			},
			// Cosign already burned the inputs server-side and inserted the
			// destination vtxos as `Unregistered`. Registration is what flips
			// them to `Spendable` on the server; a stable rejection here means
			// the recipient can't spend via the server either. They CAN still
			// emergency exit from the signed transaction chain we hold, so
			// fall through to Delivery rather than foreclose that recovery
			// path by skipping the mailbox post.
			Progress::Registration {
				movement_id, signed_destination_vtxos, signed_change_vtxos,
			} => {
				Advance::Next(ArkoorSend {
					progress: Progress::Delivery {
						movement_id,
						signed_destination_vtxos,
						signed_change_vtxos,
						last_park_error: None,
					},
					..self
				})
			},
			// Defensive: `post_arkoor_to_mailboxes` collects per-method failures
			// into the park summary rather than aborting, so this arm is
			// unreachable today. Kept as a safe fallback so that if a future
			// change starts surfacing per-method rejections we still salvage
			// the change instead of looping.
			Progress::Delivery { movement_id, signed_change_vtxos, .. } => {
				Advance::Next(ArkoorSend {
					progress: Progress::Finalizing {
						movement_id,
						signed_change_vtxos,
						delivery_succeeded: false,
					},
					..self
				})
			},
			// Only touches local state.
			Progress::Finalizing { .. } => Advance::Failed(error),
		}
	}
}

/// Build a fresh [`ArkoorSend`] in [`Progress::Cosigning`]
pub(crate) async fn start_arkoor_send(
	wallet: &Wallet,
	destination: ark::Address,
	amount: Amount,
) -> anyhow::Result<ArkoorSend> {
	let _ = wallet.require_server().await?;
	wallet.validate_arkoor_address(&destination).await
		.context("invalid arkoor address")?;

	let (change_keypair, change_key_index) = wallet.peek_next_keypair().await
		.context("failed to derive arkoor change keypair")?;
	if destination.policy().user_pubkey() == change_keypair.public_key() {
		bail!("Cannot create arkoor to same address as change");
	}
	wallet.inner.db.store_vtxo_key(change_key_index, change_keypair.public_key()).await
		.context("failed to store arkoor change keypair")?;

	// The server refuses expired vtxos as arkoor inputs; they have to wait
	// for a refresh.
	let tip = wallet.inner.chain.tip().await?;
	let inputs = wallet.spend_input_selection().await?
		.expires_after(tip)
		.select(wallet.spendable_vtxos().await?, amount)?;
	let input_vtxo_ids = inputs.iter().map(|v| v.id()).collect::<Vec<_>>();

	let total_input = inputs.iter().map(|v| v.amount()).sum::<Amount>();
	let change = total_input.checked_sub(amount)
		.context("selected inputs don't cover amount")?;

	Ok(ArkoorSend {
		id: new_action_id(),
		destination,
		amount,
		input_vtxo_ids,
		change_key_index,
		change_pieces: Some(split_change_amount(
			change, amount, wallet.config().change_vtxo_split_factor,
		)),
		progress: Progress::Cosigning,
	})
}

/// Random 128-bit identifier hex-encoded for use as the action id.
fn new_action_id() -> String {
	rand::random::<[u8; 16]>().to_lower_hex_string()
}

/// Cosigning -> Registration. Locks the inputs, cosigns the arkoor with
/// the server and records the movement.
async fn run_cosign(wallet: &Wallet, send: &ArkoorSend) -> Result<Progress, AdvanceError> {
	// Lock the inputs under the action. A re-drive finds them locked by this
	// action already, which counts as success. An input that another
	// operation took in the meantime fails the lock, and with it the send.
	// Lock before anything that can retry, so the inputs stay reserved while
	// the step waits for the server.
	wallet.lock_vtxos(
		&send.input_vtxo_ids,
		Some(VtxoLockHolder::Action { id: send.id.clone() }),
	).await.abort()?;
	let inputs = wallet.inner.db.get_wallet_vtxos(&send.input_vtxo_ids).await
		.context("failed to load arkoor inputs").retry()?;

	let change_keypair = wallet.peek_keypair(send.change_key_index).await
		.with_context(|| format!(
			"action {}: stored change_key_index {} not in keystore",
			send.id, send.change_key_index,
		)).retry()?;

	let dest = ArkoorDestination {
		total_amount: send.amount,
		policy: send.destination.policy().clone(),
	};
	let neg_amount = -send.amount.to_signed().context("amount out-of-range").abort()?;

	let arkoor = wallet.create_checkpointed_arkoor_with_vtxos(
		dest, inputs, change_keypair, send.change_pieces.clone(),
	).await.retry_unless_rejected()?;

	let initial_update = MovementUpdate::new()
		.intended_and_effective_balance(neg_amount)
		.consumed_vtxos(&arkoor.inputs)
		.sent_to([MovementDestination::ark(send.destination.clone(), send.amount)]);

	// The server has cosigned by now, so from here on only retry: the cosign
	// replays with the same change key and `abort` would release inputs
	// the server considers spent.
	let movement_id = wallet.inner.movements.get_or_create_movement_with_action(
		Subsystem::ARKOOR,
		ArkoorMovement::Send.to_string(),
		&send.id,
		initial_update,
	).await.context("failed to create arkoor movement").retry()?;

	Ok(Progress::Registration {
		movement_id,
		signed_destination_vtxos: arkoor.created,
		signed_change_vtxos: arkoor.change,
	})
}

/// Finalize the send. All steps are idempotent.
async fn finalize_arkoor_send(
	wallet: &Wallet,
	input_vtxo_ids: &[VtxoId],
	movement_id: MovementId,
	signed_change_vtxos: &[Vtxo<Full>],
	delivery_succeeded: bool,
) -> Result<(), AdvanceError> {
	wallet.mark_vtxos_as_spent(input_vtxo_ids).await.retry()?;

	if !signed_change_vtxos.is_empty() {
		wallet.store_spendable_vtxos(signed_change_vtxos.iter()).await.retry()?;
		let change_ids = signed_change_vtxos.iter()
			.map(|v| v.id())
			.collect::<Vec<_>>();
		wallet.inner.movements.update_movement(
			movement_id,
			MovementUpdate::new().produced_vtxos(&change_ids),
		).await.context("failed to record arkoor change vtxos on movement").retry()?;
	}

	let final_status = if delivery_succeeded {
		MovementStatus::Successful
	} else {
		MovementStatus::Failed
	};
	wallet.inner.movements.finish_movement(movement_id, final_status).await
		.context("failed to finalize arkoor movement").retry()?;

	if delivery_succeeded {
		info!("Successfully sent arkoor vtxos");
	}

	Ok(())
}

#[cfg(test)]
mod test {
	use super::*;

	fn dummy_send() -> ArkoorSend {
		use std::str::FromStr;
		ArkoorSend {
			id: new_action_id(),
			destination: ark::Address::from_str(
				"tark1pwh9vsmezqqpharv69q4z8m6x364d5m5prnmcalcalq9pdmzw0y7mpveck4pcfhezqypczkrrj3lkx5ue4qrf4jc7ztpt9htdttmh2judhqnu7aue8p0y9mq47jn9z",
			).unwrap(),
			amount: Amount::from_sat(10_000),
			input_vtxo_ids: vec![],
			change_key_index: 0,
			change_pieces: Some(vec![Amount::from_sat(5_000), Amount::from_sat(5_000)]),
			progress: Progress::Cosigning,
		}
	}

	/// A checkpoint written before change_pieces existed must deserialize
	/// with `None`, which rebuilds the single whole change output that
	/// version cosigned.
	#[test]
	fn checkpoint_without_change_pieces_reads_as_none() {
		let mut json = serde_json::to_value(&dummy_send()).unwrap();
		json.as_object_mut().unwrap().remove("change_pieces").unwrap();
		let old = serde_json::from_value::<ArkoorSend>(json).unwrap();
		assert_eq!(old.change_pieces, None);
	}

	#[test]
	fn change_pieces_roundtrip() {
		let send = dummy_send();
		let json = serde_json::to_value(&send).unwrap();
		assert_eq!(serde_json::from_value::<ArkoorSend>(json).unwrap(), send);
	}
}
